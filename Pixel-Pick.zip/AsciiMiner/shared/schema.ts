import { pgTable, text, serial, integer, decimal, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

export const gameStates = pgTable("game_states", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  currency: integer("currency").notNull().default(0),
  inventory: text("inventory").notNull(),
  currentPickaxe: text("current_pickaxe").notNull(),
  miningPower: decimal("mining_power").notNull().default('1'),
  recipes: text("discovered_recipes").notNull().default('[]'),
  // Combat-related fields
  playerHealth: integer("player_health").notNull().default(100),
  playerMaxHealth: integer("player_max_health").notNull().default(100),
  playerDamage: integer("player_damage").notNull().default(5),
  playerDefense: integer("player_defense").notNull().default(0),
  currentArmor: text("current_armor"),
  activeMonster: text("active_monster"),
  // Ice Golem encounter tracking
  hasEncounteredIceGolem: boolean("has_encountered_ice_golem").notNull().default(false),
  caveExitCount: integer("cave_exit_count").notNull().default(0),
  // Stats tracking
  totalMined: integer("total_mined").notNull().default(0),
  totalOreCollected: integer("total_ore_collected").notNull().default(0),
  enemiesDefeated: integer("enemies_defeated").notNull().default(0),
  currencySpent: integer("currency_spent").notNull().default(0),
  deaths: integer("deaths").notNull().default(0),
  totalDamageTaken: integer("total_damage_taken").notNull().default(0),
  // Experience system
  level: integer("level").notNull().default(1),
  experience: integer("experience").notNull().default(0),
  // Equipment tracking
  ownedPickaxes: text("owned_pickaxes").notNull().default('["wooden"]'),
  ownedArmor: text("owned_armor").notNull().default('[]'),
  // Shop unlock tracking
  hasUnlockedShop: boolean("has_unlocked_shop").notNull().default(false),
});

export const insertGameStateSchema = createInsertSchema(gameStates).pick({
  userId: true,
  currency: true,
  inventory: true,
  currentPickaxe: true,
  miningPower: true,
  recipes: true,
  playerHealth: true,
  playerMaxHealth: true,
  playerDamage: true,
  playerDefense: true,
  currentArmor: true,
  activeMonster: true,
  hasEncounteredIceGolem: true,
  caveExitCount: true,
  totalMined: true,
  totalOreCollected: true,
  enemiesDefeated: true,
  currencySpent: true,
  deaths: true,
  totalDamageTaken: true,
  level: true,
  experience: true,
  ownedPickaxes: true,
  ownedArmor: true,
  hasUnlockedShop: true,
});

export type InsertGameState = z.infer<typeof insertGameStateSchema>;
export type GameState = typeof gameStates.$inferSelect;