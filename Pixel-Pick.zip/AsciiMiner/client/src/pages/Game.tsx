import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MiningArea } from '@/components/game/MiningArea';
import { Inventory } from '@/components/game/Inventory';
import { Shop } from '@/components/game/Shop';
import { Crafting } from '@/components/game/Crafting';
import { Stats } from '@/components/game/Stats';
import { TutorialDialog } from '@/components/game/TutorialDialog';
import { useGameState, resetProgress } from '@/lib/gameState';
import type { GameState } from '@shared/schema';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { ShopIntroDialog } from '@/components/game/ShopIntroDialog';
import { FINAL_BOSS } from '@/lib/gameTypes';
import { toast } from '@/hooks/use-toast';
import { VictoryScreen } from '@/components/game/VictoryScreen';

export default function Game() {
  const { userId, updateState, showVictoryScreen, setShowVictoryScreen } = useGameState();
  const [isInCave, setIsInCave] = useState(false);
  const [showTutorial, setShowTutorial] = useState(true);
  const [showShopIntro, setShowShopIntro] = useState(false);
  const [shopIntroFromDeath, setShopIntroFromDeath] = useState(false);
  const [localShopUnlocked, setLocalShopUnlocked] = useState(false);
  const [isInFinalBoss, setIsInFinalBoss] = useState(false);

  const { data: gameState, error, isLoading } = useQuery<GameState>({
    queryKey: [`/api/game-state/${userId}`],
    retry: 3,
  });

  const handleFinalBossEntry = () => {
    if (!gameState) return;

    const inventory = JSON.parse(gameState.inventory);
    if (!inventory['ancient_key']) {
      toast({
        description: "You need the Ancient Key to enter this area!",
        duration: 3000
      });
      return;
    }

    // Show warning if under-prepared
    if (gameState.level < FINAL_BOSS.requiredLevel) {
      toast({
        description: `Warning: This powerful boss is recommended for level ${FINAL_BOSS.requiredLevel} miners. Proceed with extreme caution!`,
        duration: 5000
      });
    }

    if (!inventory['can_of_whoop_axe']) {
      toast({
        description: "Warning: The Can of Whoop Axe is highly recommended for this fight!",
        duration: 5000
      });
    }

    setIsInFinalBoss(true);
  };

  const handleExitCave = () => {
    if (!localShopUnlocked) {
      setShowShopIntro(true);
      setShopIntroFromDeath(false);
    }
    setIsInCave(false);
  };

  const handlePlayerDeath = () => {
    if (!localShopUnlocked) {
      setShowShopIntro(true);
      setShopIntroFromDeath(true);
    }
    setIsInCave(false);
  };

  const handleShopIntroClose = () => {
    if (gameState) {
      updateState({
        currency: gameState.currency + 100
      });
    }
    setLocalShopUnlocked(true);
    setShowShopIntro(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white p-4 flex items-center justify-center">
        <Card className="p-4">Loading game state...</Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 text-white p-4 flex items-center justify-center">
        <Card className="p-4 text-red-500">Error loading game state. Please refresh the page.</Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      {showTutorial && <TutorialDialog onClose={() => setShowTutorial(false)} />}
      {showShopIntro && (
        <ShopIntroDialog
          onClose={handleShopIntroClose}
          isDeath={shopIntroFromDeath}
        />
      )}
      {showVictoryScreen && (
        <VictoryScreen
          onClose={() => {
            setShowVictoryScreen(false);
            setIsInFinalBoss(false);
          }}
        />
      )}
      <div className="max-w-4xl mx-auto grid gap-4 grid-cols-1 md:grid-cols-2">
        {!isInCave && !isInFinalBoss && gameState && JSON.parse(gameState.inventory)['ancient_key'] && (
          <div className="col-span-full">
            <Card className="p-4 bg-red-900/50 border-red-600">
              <div className="text-center space-y-2">
                <h2 className="text-xl font-bold text-red-400">Ancient Door Unlocked</h2>
                <p className="text-gray-300">A mysterious door has appeared, resonating with your Ancient Key...</p>
                <Button
                  onClick={handleFinalBossEntry}
                  className="bg-red-600 hover:bg-red-700"
                >
                  Enter Ancient Chamber (Level 21)
                </Button>
              </div>
            </Card>
          </div>
        )}

        <div className="col-span-full flex justify-end">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="text-red-400 hover:text-red-300">
                Reset Progress
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action will reset all your progress including:
                  - Currency
                  - Inventory
                  - Pickaxes
                  - Mining power
                  This cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => {
                    resetProgress();
                    setLocalShopUnlocked(false);
                    setIsInFinalBoss(false);
                  }}
                  className="bg-red-600 hover:bg-red-700"
                >
                  Reset Progress
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
        <div className="col-span-full">
          <MiningArea
            isInCave={isInCave}
            setIsInCave={setIsInCave}
            onExitCave={handleExitCave}
            onPlayerDeath={handlePlayerDeath}
            isInFinalBoss={isInFinalBoss}
            setIsInFinalBoss={setIsInFinalBoss}
          />
        </div>
        <div className="space-y-4">
          <Inventory isInCave={isInCave || isInFinalBoss} />
          <Stats />
        </div>
        {!isInCave && !isInFinalBoss && localShopUnlocked && (
          <div className="space-y-4">
            <Shop />
            <Crafting />
          </div>
        )}
      </div>
    </div>
  );
}