import { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Cutscene } from '@/components/game/Cutscene';

export default function TitleScreen() {
  const [, setLocation] = useLocation();
  const [showCutscene, setShowCutscene] = useState(true);

  return (
    <>
      {showCutscene ? (
        <Cutscene onComplete={() => setShowCutscene(false)} />
      ) : (
        <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
          <Card className="p-8 bg-gray-800 max-w-2xl w-full mx-4">
            <pre className="font-mono text-center text-yellow-500 text-xs sm:text-sm md:text-base whitespace-pre mb-8">
{`
██████╗ ██╗██╗  ██╗███████╗██╗         ██████╗ ██╗ ██████╗██╗  ██╗
██╔══██╗██║╚██╗██╔╝██╔════╝██║         ██╔══██╗██║██╔════╝██║ ██╔╝
██████╔╝██║ ╚███╔╝ █████╗  ██║         ██████╔╝██║██║     █████╔╝ 
██╔═══╝ ██║ ██╔██╗ ██╔══╝  ██║         ██╔═══╝ ██║██║     ██╔═██╗ 
██║     ██║██╔╝ ██╗███████╗███████╗    ██║     ██║╚██████╗██║  ██╗
╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝    ╚═╝     ╚═╝ ╚═════╝╚═╝  ╚═╝
`}
            </pre>
            <div className="text-center">
              <Button 
                onClick={() => setLocation('/game')}
                size="lg"
                className="bg-yellow-600 hover:bg-yellow-700 text-lg px-8 py-6"
              >
                Start Game
              </Button>
            </div>
          </Card>
        </div>
      )}
    </>
  );
}