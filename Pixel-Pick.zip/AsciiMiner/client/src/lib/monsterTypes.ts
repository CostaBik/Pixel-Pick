import { z } from "zod";

export interface Monster {
  id: string;
  name: string;
  displayName: string;
  symbol: string;
  color: string;
  health: number;
  damage: number;
  mineralDrops: Record<string, number>; // resource name -> amount
  description: string;
}

export const MONSTERS: Monster[] = [
  {
    id: "ice_golem",
    name: "ice_golem",
    displayName: "Ice Golem",
    symbol: "❄",
    color: "text-blue-300",
    health: 200,
    damage: 12,
    mineralDrops: {},
    description: "A rare and powerful creature made of ancient ice."
  },
  {
    id: "geode_basic",
    name: "geode_basic",
    displayName: "Crystal Geode",
    symbol: "◊",
    color: "text-purple-400",
    health: 20,
    damage: 5,
    mineralDrops: { "coal": 2, "copper_ore": 1 },
    description: "A basic crystalline formation that has become sentient."
  },
  {
    id: "crystal_golem",
    name: "crystal_golem",
    displayName: "Crystal Golem",
    symbol: "Ω",
    color: "text-blue-400",
    health: 40,
    damage: 8,
    mineralDrops: { "iron_ore": 2, "titanium_ore": 1 },
    description: "A hulking mass of crystals that has taken a humanoid form."
  },
  {
    id: "diamond_sentinel",
    name: "diamond_sentinel",
    displayName: "Diamond Sentinel",
    symbol: "♦",
    color: "text-cyan-400",
    health: 60,
    damage: 12,
    mineralDrops: { "diamond": 1, "platinum_ore": 2 },
    description: "An ancient guardian formed from pure diamond."
  },
  {
    id: "tungsten_wurm",
    name: "tungsten_wurm",
    displayName: "Tungsten Wurm",
    symbol: "~",
    color: "text-gray-400",
    health: 80,
    damage: 15,
    mineralDrops: { "tungsten_ore": 2 },
    description: "A metallic serpentine creature that burrows through solid rock."
  }
];

// Define which monsters can spawn in which levels
export const LEVEL_MONSTERS: Record<number, string[]> = {
  1: ["geode_basic"],
  2: ["geode_basic"],
  3: ["geode_basic", "crystal_golem"],
  4: ["geode_basic", "crystal_golem"],
  5: ["crystal_golem"],
  6: ["crystal_golem"],
  7: ["crystal_golem", "diamond_sentinel"],
  8: ["crystal_golem", "diamond_sentinel"],
  9: ["diamond_sentinel"],
  10: ["diamond_sentinel"],
  11: ["diamond_sentinel", "tungsten_wurm"],
  12: ["diamond_sentinel", "tungsten_wurm"],
  13: ["tungsten_wurm"],
  14: ["tungsten_wurm"],
  15: ["tungsten_wurm"],
  16: ["tungsten_wurm"],
  17: ["tungsten_wurm"],
  18: ["tungsten_wurm"],
  19: ["tungsten_wurm"],
  20: ["tungsten_wurm"],
};

export const monsterSchema = z.object({
  id: z.string(),
  name: z.string(),
  displayName: z.string(),
  symbol: z.string(),
  color: z.string(),
  health: z.number(),
  damage: z.number(),
  mineralDrops: z.record(z.string(), z.number()),
  description: z.string(),
});

export type MonsterType = z.infer<typeof monsterSchema>;