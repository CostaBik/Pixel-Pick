export const CAVE_ENTRANCE = `
    ╔══════════════════════════════════════╗
    ║           MINE ENTRANCE              ║
    ║                                      ║
    ║       ▄▄███████████████▄▄            ║
    ║      ██████████████████████          ║
    ║     ████████ ENTER ████████          ║
    ║    ██████████████████████████        ║
    ╚══════════════════════════════════════╝

    ╔═══════ Ancient Sign ═══════╗
    ║     📜 Read the Riddle     ║
    ╚════════════════════════════╝
`;

export const CAVE_RIDDLE = `
    In the depths of this cave, four beasts reside,
    Each guarding a path where secrets hide.
    On the outer paths, two mid-level foes,
    Guarding their secrets where the journey slows.
    Take the middle path to find the weakest,
    But beware, the strongest also lies in this quest.
    Seek the weakest first, to build your skill,
    Then face the strongest, if you will.
`;

export const LEVEL_1 = `
    ╔═══════ Main Cave ═══════╗
      ▄▄███████▄▄                         
    ▄████████████▄                         
   ██████████████████                         
  ████████████████████             %PLAYER%
 ██████████████████████           %PLAYER2%
████████████████████████          %PLAYER3%
`;

export const LEVEL_2 = `
    ╔═══════ Deep Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_3 = `
    ╔═══════ Deeper Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_4 = `
    ╔═══════ Dark Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_5 = `
    ╔═══════ Hidden Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_6 = `
    ╔═══════ Lost Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_7 = `
    ╔═══════ Forgotten Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_8 = `
    ╔═══════ Secret Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_9 = `
    ╔═══════ Ancient Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_10 = `
    ╔═══════ Mystical Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_11 = `
    ╔═══════ Enchanted Cave ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_12 = `
    ╔═══════ Hidden Depths ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_13 = `
    ╔═══════ Shadowy Abyss ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_14 = `
    ╔═══════ Crystal Caverns ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_15 = `
    ╔═══════ Sunken Grotto ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_16 = `
    ╔═══════ Twisted Tunnels ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_17 = `
    ╔═══════ Labyrinthine Passages ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_18 = `
    ╔═══════ Underground River ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_19 = `
    ╔═══════ Volcanic Chambers ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const LEVEL_20 = `
    ╔═══════ The Core ═══════╗
   ▄▄████▄▄                         
  ▄██████████▄                         
 ███████████████                         
████████████████             %PLAYER%
███████████████             %PLAYER2%
██████████████             %PLAYER3%
`;

export const MINING_ANIMATION = [
`⛏    O     
     /|\\   
     / \\   `,

`     O     
⛏  /|\\   
     / \\   `,

`     O    
     /|\\   
⛏  / \\   `,

`     O    
⛏  /|\\   
     / \\   `
];

export function generateMiningArea(resources: string[][]): string {
  let output = "";
  for (let row of resources) {
    output += row.join(" ") + "\n";
  }
  return output;
}