import { create } from 'zustand';
import { RESOURCES, PICKAXES, type Inventory, ARMOR_ITEMS, HEALTH_ITEMS, SPECIAL_ITEMS, PICKAXE_TIERS, RESOURCE_TIERS, FINAL_BOSS } from './gameTypes';
import { type Monster, MONSTERS } from './monsterTypes';
import { apiRequest } from './queryClient';
import { toast } from '@/hooks/use-toast';

interface GameState {
  userId: string;
  currency: number;
  inventory: Inventory;
  currentPickaxe: string;
  miningPower: number;
  playerHealth: number;
  playerMaxHealth: number;
  playerDamage: number;
  playerDefense: number;
  currentArmor: string | null;
  activeMonster: Monster | null;
  hasEncounteredIceGolem: boolean;
  caveExitCount: number;
  // Stats
  totalMined: number;
  totalOreCollected: number;
  enemiesDefeated: number;
  currencySpent: number;
  deaths: number;
  totalDamageTaken: number;
  // Experience system
  level: number;
  experience: number;
  ownedPickaxes: string[];
  ownedArmor: string[];
  showVictoryScreen: boolean;
  updateState: (updates: Partial<Omit<GameState, 'updateState'>>) => void;
}

export const useGameState = create<GameState>((set) => ({
  userId: "player1",
  currency: 0,  // Start with 0 currency
  inventory: {},
  currentPickaxe: "wooden",
  miningPower: 1.0,
  playerHealth: 100,
  playerMaxHealth: 100,
  playerDamage: 3,
  playerDefense: 0,
  currentArmor: null,
  activeMonster: null,
  hasEncounteredIceGolem: false,
  caveExitCount: 0,
  // Initialize stats
  totalMined: 0,
  totalOreCollected: 0,
  enemiesDefeated: 0,
  currencySpent: 0,
  deaths: 0,
  totalDamageTaken: 0,
  // Initialize experience system
  level: 1,
  experience: 0,
  ownedPickaxes: ["wooden"],
  ownedArmor: [],
  showVictoryScreen: false,
  updateState: (updates) => set((state) => ({ ...state, ...updates })),
}));

// Helper function to calculate required XP for next level
const getRequiredExp = (level: number): number => {
  if (level <= 5) return 250;
  if (level <= 10) return 400;
  if (level <= 15) return 700;
  return 1000;
};

// Helper function to calculate XP reward based on monster level
const getMonsterExpReward = (monsterName: string): number => {
  switch (monsterName) {
    case 'geode_basic': return 25;
    case 'crystal_golem': return 50;
    case 'diamond_sentinel': return 75;
    case 'tungsten_wurm': return 100;
    case 'ice_golem': return 500;
    default: return 25;
  }
};

// Helper function to handle level-up rewards
const getLevelUpReward = (level: number) => {
  const currency = level * 5;
  let specialItem = null;
  let message = `Level Up! You reached level ${level} and earned ${currency} currency!`;

  if (level === 10) {
    specialItem = SPECIAL_ITEMS.sledgehammer;
    message += `\nSpecial Reward: ${specialItem.displayName}!`;
  } else if (level === 15) {
    specialItem = SPECIAL_ITEMS.cave_map;
    message += `\nSpecial Reward: ${specialItem.displayName}!`;
  } else if (level === 20) {
    specialItem = SPECIAL_ITEMS.rubber_mallet;
    message += `\nSpecial Reward: ${specialItem.displayName}!`;
  }

  return { currency, specialItem, message };
};

// Function to handle leveling up
const checkLevelUp = async () => {
  const state = useGameState.getState();
  const requiredExp = getRequiredExp(state.level);

  if (state.level < 20 && state.experience >= requiredExp) {
    const newLevel = state.level + 1;
    const reward = getLevelUpReward(newLevel);

    const inventory = { ...state.inventory };
    if (reward.specialItem) {
      inventory[reward.specialItem.name] = 1;
    }

    useGameState.setState({
      level: newLevel,
      experience: state.experience - requiredExp,
      playerMaxHealth: 100 + (newLevel - 1) * 10,
      playerHealth: 100 + (newLevel - 1) * 10,
      playerDamage: Math.floor(state.miningPower * 2),
      currency: state.currency + reward.currency,
      inventory
    });

    // Show level up message
    toast({
      title: "Level Up!",
      description: reward.message,
      duration: 5000,
    });

    await saveGameState();
  }
};

// Update saveGameState function to include new stats
async function saveGameState() {
  const state = useGameState.getState();
  try {
    await apiRequest('POST', `/api/game-state/${state.userId}`, {
      currency: state.currency,
      inventory: JSON.stringify(state.inventory),
      currentPickaxe: state.currentPickaxe,
      miningPower: state.miningPower.toString(),
      playerHealth: state.playerHealth,
      playerMaxHealth: state.playerMaxHealth,
      playerDamage: state.playerDamage,
      playerDefense: state.playerDefense,
      currentArmor: state.currentArmor,
      activeMonster: state.activeMonster ? JSON.stringify(state.activeMonster) : null,
      hasEncounteredIceGolem: state.hasEncounteredIceGolem,
      caveExitCount: state.caveExitCount,
      totalMined: state.totalMined,
      totalOreCollected: state.totalOreCollected,
      enemiesDefeated: state.enemiesDefeated,
      currencySpent: state.currencySpent,
      deaths: state.deaths,
      totalDamageTaken: state.totalDamageTaken,
      level: state.level,
      experience: state.experience,
      ownedPickaxes: JSON.stringify(state.ownedPickaxes),
      ownedArmor: JSON.stringify(state.ownedArmor),
      showVictoryScreen: state.showVictoryScreen
    });
  } catch (error) {
    console.error('Failed to save game state:', error);
  }
}

// Update the mine function to strictly enforce tier progression
export const mine = async () => {
  const state = useGameState.getState();

  // Ice Golem encounter check
  if (!state.hasEncounteredIceGolem && Math.random() < 0.01) {
    const iceGolem = MONSTERS.find(m => m.name === 'ice_golem');
    if (iceGolem) {
      useGameState.setState({ activeMonster: iceGolem, hasEncounteredIceGolem: true });
      await saveGameState();
      return;
    }
  }

  // Increment total mined count
  useGameState.setState(state => ({ totalMined: state.totalMined + 1 }));

  // Get current pickaxe tier
  const currentPickaxeTier = PICKAXE_TIERS[state.currentPickaxe as keyof typeof PICKAXE_TIERS];

  // Filter resources based on strict tier progression
  const availableResources = RESOURCES.filter(resource => {
    const resourceTier = RESOURCE_TIERS[resource.name as keyof typeof RESOURCE_TIERS];
    // For wooden pickaxe (tier 0), only allow coal (tier 1)
    if (currentPickaxeTier === 0) return resourceTier === 1;
    // For all other pickaxes, allow current tier and one below
    return resourceTier <= currentPickaxeTier + 1 && resourceTier >= Math.max(1, currentPickaxeTier - 1);
  });

  if (availableResources.length === 0) return;

  // Select a random resource from available ones
  const resource = availableResources[Math.floor(Math.random() * availableResources.length)];

  // Check if using sledgehammer
  const hasSledgehammer = state.inventory['sledgehammer'] === 1;
  const shouldMine = !hasSledgehammer || Math.random() < 0.5; // 50% chance with sledgehammer

  if (!shouldMine) {
    console.log('Sledgehammer missed!');
    return;
  }

  // Perfect vein logic
  const isPerfectVein = Math.random() < 0.1;
  const amount = isPerfectVein ?
    Math.floor(Math.random() * 9) + 2 :
    1;

  console.log(
    isPerfectVein
      ? `Perfect vein hit! Found ${amount}x ${resource.displayName}`
      : `Mined 1x ${resource.displayName}`
  );

  const inventory = { ...state.inventory };
  inventory[resource.name] = (inventory[resource.name] || 0) + amount;

  useGameState.setState(state => ({
    inventory,
    totalOreCollected: state.totalOreCollected + amount
  }));
  await saveGameState();
};

// Update attackMonster to handle rubber mallet's special ability
const checkAndCombineKeyFragments = (inventory: Inventory) => {
  const fragments = [
    'key_fragment_a',
    'key_fragment_b',
    'key_fragment_c',
    'key_fragment_d'
  ];

  // Check if we have all fragments
  const hasAllFragments = fragments.every(fragment => inventory[fragment] === 1);

  if (hasAllFragments) {
    // Remove fragments and add the key
    fragments.forEach(fragment => delete inventory[fragment]);
    inventory['ancient_key'] = 1;

    // Show a toast notification
    toast({
      description: "The key fragments resonate with each other and combine into an Ancient Key!",
      duration: 5000,
    });
  }

  return inventory;
};

// Add function to check and combine spr-axe components
const checkAndCombineSprAxeComponents = (inventory: Inventory) => {
  const components = [
    'axe_body_spraxe_fresh',
    'axe_body_spraxe_mountain',
    'axe_body_spraxe_cool'
  ];

  // Check if we have all components
  const hasAllComponents = components.every(component => inventory[component] === 1);

  if (hasAllComponents) {
    // Remove components and add the Can of Whoop Axe
    components.forEach(component => delete inventory[component]);
    inventory['can_of_whoop_axe'] = 1;

    // Update game state to use the new pickaxe
    useGameState.setState({
      inventory,
      currentPickaxe: 'can_of_whoop_axe',
      miningPower: SPECIAL_PICKAXES.can_of_whoop_axe.power,
      playerDamage: SPECIAL_PICKAXES.can_of_whoop_axe.damage
    });

    // Show a toast notification
    toast({
      description: "The Axe Body Spr-axe components combine to form the legendary Can of Whoop Axe!",
      duration: 5000,
    });
  }

  return inventory;
};

// Update attackMonster function to handle both key fragments and spr-axe components
export const attackMonster = async () => {
  const state = useGameState.getState();
  if (!state.activeMonster) return;

  const monster = { ...state.activeMonster };

  let damage = state.playerDamage;

  // Special handling for rubber mallet
  if (state.inventory['rubber_mallet'] === 1) {
    const random = Math.random();
    let cumulative = 0;
    for (let i = 0; i < SPECIAL_ITEMS.rubber_mallet.damageRanges.length; i++) {
      cumulative += SPECIAL_ITEMS.rubber_mallet.probabilities[i];
      if (random <= cumulative) {
        damage = SPECIAL_ITEMS.rubber_mallet.damageRanges[i];
        break;
      }
    }
    console.log(`Rubber Mallet hit for ${damage} damage!`);
  }

  monster.health -= damage;

  if (monster.health <= 0) {
    const inventory = { ...state.inventory };

    // Add monster's mineral drops to inventory
    Object.entries(monster.mineralDrops).forEach(([mineral, amount]) => {
      inventory[mineral] = (inventory[mineral] || 0) + amount;
    });

    // Check if this was a boss fight and award special loot
    const bossRoom = Object.values(BOSS_ROOMS).find(boss => boss.name === monster.name);
    if (bossRoom) {
      // Add key fragment if specified
      if (bossRoom.loot.keyFragment) {
        inventory[bossRoom.loot.keyFragment] = 1;
        toast({
          description: "You found a mysterious key fragment!",
          duration: 3000
        });
      }
      // Add spr-axe component if specified
      if (bossRoom.loot.sprAxe) {
        inventory[bossRoom.loot.sprAxe] = 1;
        toast({
          description: "You found an Axe Body Spr-axe component!",
          duration: 3000
        });
      }
    }

    // Check for both key fragment and spr-axe component combinations
    let updatedInventory = checkAndCombineKeyFragments(inventory);
    updatedInventory = checkAndCombineSprAxeComponents(updatedInventory);

    // Award experience points for defeating the monster
    const expReward = getMonsterExpReward(monster.name);
    const newExp = state.experience + expReward;

    // Show victory screen if Ancient Guardian is defeated
    const showVictoryScreen = monster.name === FINAL_BOSS.name;

    useGameState.setState(state => ({
      activeMonster: null,
      inventory: updatedInventory,
      enemiesDefeated: state.enemiesDefeated + 1,
      experience: newExp,
      showVictoryScreen
    }));

    // Check for level up after gaining experience
    await checkLevelUp();

    if (monster.name === 'ice_golem') {
      await rewardIcePickaxe();
    }
  } else {
    const monsterDamage = Math.max(0, monster.damage - state.playerDefense);
    const playerHealth = Math.max(0, state.playerHealth - monsterDamage);

    if (playerHealth <= 0) {
      useGameState.setState(state => ({
        playerHealth: state.playerMaxHealth,
        inventory: {},
        activeMonster: null,
        deaths: state.deaths + 1,
        totalDamageTaken: state.totalDamageTaken + monsterDamage
      }));
      return true;
    }

    useGameState.setState(state => ({
      activeMonster: monster,
      playerHealth,
      totalDamageTaken: state.totalDamageTaken + monsterDamage
    }));
  }
  await saveGameState();
  return false;
};

export const rewardIcePickaxe = async () => {
  const state = useGameState.getState();
  const inventory = { ...state.inventory };
  inventory['ice_pickaxe'] = 1;

  useGameState.setState({
    inventory,
    currentPickaxe: 'ice',
    miningPower: 9.0,
    playerDamage: Math.floor(9.0 * 2)
  });
  await saveGameState();
};

export const sellResource = async (resourceName: string) => {
  const state = useGameState.getState();
  const resource = RESOURCES.find(r => r.name === resourceName);
  if (!resource || !state.inventory[resourceName]) return;

  const amount = state.inventory[resourceName];
  const value = resource.value * amount;

  const inventory = { ...state.inventory };
  delete inventory[resourceName];

  useGameState.setState({
    inventory,
    currency: state.currency + value
  });
  await saveGameState();
};

export const buyPickaxe = async (pickaxeName: string) => {
  const state = useGameState.getState();
  const pickaxe = PICKAXES.find(p => p.name === pickaxeName);
  if (!pickaxe || pickaxe.cost === null || state.currency < pickaxe.cost) return;

  useGameState.setState(state => ({
    currency: state.currency - pickaxe.cost,
    currencySpent: state.currencySpent + pickaxe.cost,
    currentPickaxe: pickaxe.name,
    miningPower: pickaxe.power,
    playerDamage: Math.floor(pickaxe.power * 2),
    ownedPickaxes: [...state.ownedPickaxes, pickaxe.name]
  }));
  await saveGameState();
};

export const craftPickaxe = async (pickaxeName: string) => {
  const state = useGameState.getState();
  const pickaxe = PICKAXES.find(p => p.name === pickaxeName);
  if (!pickaxe || !pickaxe.recipe) return;

  // Check if we have all required materials
  const canCraft = Object.entries(pickaxe.recipe).every(
    ([item, amount]) => (state.inventory[item] ?? 0) >= amount
  );

  if (!canCraft) return;

  // Remove materials used in crafting
  const inventory = { ...state.inventory };
  Object.entries(pickaxe.recipe).forEach(([item, amount]) => {
    inventory[item] -= amount;
    if (inventory[item] <= 0) {
      delete inventory[item];
    }
  });

  useGameState.setState({
    inventory,
    currentPickaxe: pickaxe.name,
    miningPower: pickaxe.power,
    playerDamage: Math.floor(pickaxe.power * 2)
  });
  await saveGameState();
};

// Health and Armor related functions
export const buyHealthItem = async (itemName: string) => {
  const state = useGameState.getState();
  const item = HEALTH_ITEMS.find(i => i.name === itemName);
  if (!item || state.currency < item.cost) return;

  const inventory = { ...state.inventory };
  inventory[itemName] = (inventory[itemName] || 0) + 1;

  useGameState.setState({
    currency: state.currency - item.cost,
    currencySpent: state.currencySpent + item.cost,
    inventory
  });
  await saveGameState();
};

export const useHealthItem = async (itemName: string) => {
  const state = useGameState.getState();
  const item = HEALTH_ITEMS.find(i => i.name === itemName);
  if (!item || !state.inventory[itemName]) return;

  const inventory = { ...state.inventory };
  inventory[itemName]--;
  if (inventory[itemName] <= 0) {
    delete inventory[itemName];
  }

  const newHealth = Math.min(state.playerMaxHealth, state.playerHealth + item.healAmount);
  useGameState.setState({
    inventory,
    playerHealth: newHealth
  });
  await saveGameState();
};

export const buyArmor = async (armorName: string) => {
  const state = useGameState.getState();
  const armor = ARMOR_ITEMS.find(a => a.name === armorName);
  if (!armor || armor.cost === null || state.currency < armor.cost) return;

  useGameState.setState(state => ({
    currency: state.currency - armor.cost,
    currencySpent: state.currencySpent + armor.cost,
    currentArmor: armor.name,
    playerDefense: armor.defense,
    ownedArmor: [...state.ownedArmor, armor.name]
  }));
  await saveGameState();
};

export const craftArmor = async (armorName: string) => {
  const state = useGameState.getState();
  const armor = ARMOR_ITEMS.find(a => a.name === armorName);
  if (!armor || !armor.recipe) return;

  // Check if we have all required materials
  const canCraft = Object.entries(armor.recipe).every(
    ([item, amount]) => (state.inventory[item] ?? 0) >= amount
  );

  if (!canCraft) return;

  // Remove materials used in crafting
  const inventory = { ...state.inventory };
  Object.entries(armor.recipe).forEach(([item, amount]) => {
    inventory[item] -= amount;
    if (inventory[item] <= 0) {
      delete inventory[item];
    }
  });

  useGameState.setState({
    inventory,
    currentArmor: armor.name,
    playerDefense: armor.defense
  });
  await saveGameState();
};

// Combat related functions
export const startCombat = async (monster: Monster) => {
  useGameState.setState({ activeMonster: monster });
  await saveGameState();
};


export const exitCave = async () => {
  const state = useGameState.getState();
  const inventory = { ...state.inventory };

  // Check if player has Ice Pickaxe
  if (inventory['ice_pickaxe']) {
    const caveExitCount = state.caveExitCount + 1;
    if (caveExitCount >= 3) {
      // Remove Ice Pickaxe after 3 cave exits
      delete inventory['ice_pickaxe'];
      useGameState.setState({
        inventory,
        currentPickaxe: 'wooden',
        miningPower: 1.0,
        playerDamage: 3,
        caveExitCount: 0
      });
    } else {
      useGameState.setState({ caveExitCount });
    }
  }

  // Always restore health to full when exiting cave
  useGameState.setState({
    playerHealth: state.playerMaxHealth,
    activeMonster: null
  });
  await saveGameState();
};

export const resetProgress = async () => {
  // Reset to initial state
  useGameState.setState({
    currency: 0, // Start with 0 currency
    inventory: {},
    currentPickaxe: "wooden",
    miningPower: 1.0,
    playerHealth: 100,
    playerMaxHealth: 100,
    playerDamage: 3,
    playerDefense: 0,
    currentArmor: null,
    activeMonster: null,
    hasEncounteredIceGolem: false,
    caveExitCount: 0,
    totalMined: 0,
    totalOreCollected: 0,
    enemiesDefeated: 0,
    currencySpent: 0,
    deaths: 0,
    totalDamageTaken: 0,
    level: 1,
    experience: 0,
    ownedPickaxes: ["wooden"],
    ownedArmor: [],
    showVictoryScreen: false
  });

  // Save reset state to server
  await saveGameState();
};


// Add new functions for equipment management
export const changePickaxe = async (pickaxeName: string) => {
  const state = useGameState.getState();
  if (!state.ownedPickaxes.includes(pickaxeName)) return;

  const pickaxe = PICKAXES.find(p => p.name === pickaxeName);
  if (!pickaxe) return;

  useGameState.setState({
    currentPickaxe: pickaxe.name,
    miningPower: pickaxe.power,
    playerDamage: Math.floor(pickaxe.power * 2)
  });
  await saveGameState();
};

export const changeArmor = async (armorName: string | null) => {
  const state = useGameState.getState();
  if (armorName && !state.ownedArmor.includes(armorName)) return;

  const armor = armorName ? ARMOR_ITEMS.find(a => a.name === armorName) : null;
  useGameState.setState({
    currentArmor: armorName,
    playerDefense: armor ? armor.defense : 0
  });
  await saveGameState();
};

// Assuming BOSS_ROOMS is defined elsewhere and contains boss data
const BOSS_ROOMS = {
  //Example
  "ancient_guardian": {
    name: "ancient_guardian",
    loot: {
      keyFragment: "ancient_key_fragment",
      sprAxe: "axe_body_spraxe_fresh"
    }
  }
  // Add other boss rooms here...
};

const SPECIAL_PICKAXES = {
  can_of_whoop_axe: {
    power: 15,
    damage: 30
  }
}