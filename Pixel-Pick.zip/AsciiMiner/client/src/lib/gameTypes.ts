import { z } from "zod";

export interface Resource {
  name: string;
  displayName: string;
  value: number;
  symbol: string;
  color: string;
  requiredPower: number;
  minPower: number;  // Minimum power needed
  maxPower: number;  // Maximum power that can mine this
}

export interface Pickaxe {
  name: string;
  displayName: string;
  power: number;
  cost: number | null; // null means it must be crafted
  symbol: string;
  color: string;
  recipe?: Record<string, number>; // required materials and their amounts
  description?: string;
  damage?:number;
}

export interface HealthItem {
  name: string;
  displayName: string;
  healAmount: number;
  cost: number;
  symbol: string;
  color: string;
}

export interface Armor {
  name: string;
  displayName: string;
  defense: number;
  cost: number | null; // null means it must be crafted
  symbol: string;
  color: string;
  recipe?: Record<string, number>;
  description?: string;
}

export interface Inventory {
  [key: string]: number;
}

export const RESOURCES: Resource[] = [
  { 
    name: "coal", 
    displayName: "Coal", 
    value: 1, 
    symbol: "■", 
    color: "text-gray-600", 
    requiredPower: 0.5,
    minPower: 0.5,
    maxPower: 1.5
  },
  { 
    name: "copper_ore", 
    displayName: "Copper Ore", 
    value: 2, 
    symbol: "◆", 
    color: "text-orange-400", 
    requiredPower: 1.0,
    minPower: 1.0,
    maxPower: 2.0
  },
  { 
    name: "iron_ore", 
    displayName: "Iron Ore", 
    value: 3, 
    symbol: "●", 
    color: "text-gray-400", 
    requiredPower: 1.5,
    minPower: 1.5,
    maxPower: 2.5
  },
  { 
    name: "titanium_ore", 
    displayName: "Titanium Ore", 
    value: 5, 
    symbol: "♦", 
    color: "text-cyan-400", 
    requiredPower: 2.0,
    minPower: 2.0,
    maxPower: 3.0
  },
  { 
    name: "platinum_ore", 
    displayName: "Platinum Ore", 
    value: 8, 
    symbol: "★", 
    color: "text-blue-200", 
    requiredPower: 2.5,
    minPower: 2.5,
    maxPower: 3.5
  },
  { 
    name: "tungsten_ore", 
    displayName: "Tungsten Ore", 
    value: 12, 
    symbol: "✧", 
    color: "text-purple-400", 
    requiredPower: 3.0,
    minPower: 3.0,
    maxPower: 4.0
  },
  { 
    name: "diamond", 
    displayName: "Diamond", 
    value: 15, 
    symbol: "💎", 
    color: "text-blue-400", 
    requiredPower: 3.5,
    minPower: 3.5,
    maxPower: 4.0
  }
];

export const PICKAXES: Pickaxe[] = [
  { name: "wooden", displayName: "Wooden Pickaxe", power: 1.0, cost: 0, symbol: "⚒", color: "text-yellow-800", description: "A humble beginning for any aspiring miner." },
  { name: "stone", displayName: "Stone Pickaxe", power: 2.0, cost: 100, symbol: "⛏", color: "text-gray-500", description: "Sturdy and reliable, like the rocks it's made from." },
  { name: "copper", displayName: "Copper Pickaxe", power: 3.0, cost: null, symbol: "🔨", color: "text-orange-400", 
    recipe: { copper_ore: 15 }, description: "Conducts more than just electricity - it conducts mining spirit!" },
  { name: "iron", displayName: "Iron Pickaxe", power: 4.0, cost: 500, symbol: "⚒", color: "text-gray-300", description: "The trusty workhorse of any serious miner." },
  { name: "titanium", displayName: "Titanium Pickaxe", power: 5.0, cost: null, symbol: "⛏", color: "text-cyan-400",
    recipe: { titanium_ore: 15, iron_ore: 10 }, description: "Lightweight yet powerful, perfect for extended mining sessions." },
  { name: "platinum", displayName: "Platinum Pickaxe", power: 6.0, cost: null, symbol: "🔨", color: "text-blue-200",
    recipe: { platinum_ore: 12, titanium_ore: 8 }, description: "A premium tool for the discerning miner." },
  { name: "tungsten", displayName: "Tungsten Pickaxe", power: 7.0, cost: null, symbol: "⚒", color: "text-purple-400",
    recipe: { tungsten_ore: 10, platinum_ore: 6 }, description: "Heavy duty mining for heavy duty miners." },
  { name: "diamond", displayName: "Diamond Pickaxe", power: 8.0, cost: 3000, symbol: "💎", color: "text-blue-400", description: "The pinnacle of traditional mining technology." },
  { name: "ice", displayName: "Ice Pickaxe", power: 9.0, cost: null, symbol: "❄", color: "text-blue-300", description: "Melts after a certain amount of trips to the mine." },
  { name: "pickhacks", displayName: "PickHacks", power: 10.0, cost: 10101, symbol: "🔮", color: "text-green-400", description: "You know who you are." },
  { name: "sledgehammer", displayName: "Sledgehammer", power: 6.0, cost: null, symbol: "🔨", color: "text-yellow-600", 
    description: "A powerful hammer awarded for reaching level 10. Has 50% chance to get resources when mining.", damage: 14 }
];

export const HEALTH_ITEMS: HealthItem[] = [
  { 
    name: "small_potion", 
    displayName: "Small Health Potion", 
    healAmount: 25, 
    cost: 100, 
    symbol: "🧪",
    color: "text-red-300"
  },
  { 
    name: "medium_potion", 
    displayName: "Medium Health Potion", 
    healAmount: 50, 
    cost: 300, 
    symbol: "🧪",
    color: "text-red-400"
  },
  { 
    name: "large_potion", 
    displayName: "Large Health Potion", 
    healAmount: 100, 
    cost: 800, 
    symbol: "🧪",
    color: "text-red-500"
  }
];

export const ARMOR_ITEMS: Armor[] = [
  { 
    name: "copper_armor", 
    displayName: "Copper Armor", 
    defense: 2, 
    cost: 200, 
    symbol: "🛡️",
    color: "text-orange-400",
    description: "Basic protection that doubles as a conversation starter."
  },
  { 
    name: "iron_armor", 
    displayName: "Iron Armor", 
    defense: 4, 
    cost: 600, 
    symbol: "🛡️",
    color: "text-gray-400",
    description: "Standard-issue protection for the everyday miner."
  },
  { 
    name: "platinum_armor", 
    displayName: "Platinum Armor", 
    defense: 6, 
    cost: 1500, 
    symbol: "🛡️",
    color: "text-blue-200",
    description: "Shiny enough to blind your enemies."
  },
  { 
    name: "tungsten_armor", 
    displayName: "Tungsten Armor", 
    defense: 8, 
    cost: 2500, 
    symbol: "🛡️",
    color: "text-purple-400",
    description: "Heavy but worth every ounce of protection."
  },
  { 
    name: "titanium_armor", 
    displayName: "Titanium Armor", 
    defense: 10, 
    cost: null, 
    symbol: "🛡️",
    color: "text-cyan-400",
    recipe: { titanium_ore: 35, iron_ore: 25 },
    description: "Aerospace-grade protection for underground adventures."
  },
  { 
    name: "diamond_armor", 
    displayName: "Diamond Armor", 
    defense: 12, 
    cost: null, 
    symbol: "🛡️",
    color: "text-blue-400",
    recipe: { diamond: 30, titanium_ore: 20 },
    description: "The ultimate in crystalline protection technology."
  }
];

export const SHOP_PICKAXES = PICKAXES.filter(p => p.cost !== null);
export const CRAFTABLE_PICKAXES = PICKAXES.filter(p => p.recipe !== undefined);
export const SHOP_ARMOR = ARMOR_ITEMS.filter(a => a.cost !== null);
export const CRAFTABLE_ARMOR = ARMOR_ITEMS.filter(a => a.recipe !== undefined);

export const SPECIAL_ITEMS = {
  cave_map: {
    name: "cave_map",
    displayName: "Cave Map",
    symbol: "🗺️",
    color: "text-brown-400",
    description: "A detailed map of the cave system awarded for reaching level 15.",
    mapArt: `
    ╔════ MINE MAP ════╗   LEGEND:
    ║     Entry        ║   [B] - Boss Room
    ║      ║          ║   👾 - Crystal Titan
    ║     Main        ║   🗿 - Ore Guardian
    ║    ╱  ╲         ║   👻 - Shadow Colossus
    ║  Left  Right    ║   🗿 - Ancient Golem
    ║   ║    ║        ║   
    ║  Safe  Hard     ║   
    ║   ║    ║        ║   
    ║  Deep  Deep     ║   
    ║ ╱ ╲  ╱  ╲       ║   
    ║[9][10][11][12]  ║   
    ║ ║  ║   ║   ║    ║   
    ║[13][14][15][16] ║   
    ║ ║  ║   ║   ║    ║   
    ║[B][B] [B] [B]   ║   
    ║ 👾 🗿  👻  🗿    ║   
    ╚══════════════════╝   
    `
  },
  rubber_mallet: {
    name: "rubber_mallet",
    displayName: "Rubber Mallet",
    symbol: "🔧",
    color: "text-purple-300",
    description: "Truly a weapon of mass destruction.",
    power: 1.0,
    damageRanges: [1, 2, 4, 8, 16, 32, 64, 128, 256],
    probabilities: [0.3, 0.2, 0.15, 0.1, 0.08, 0.07, 0.05, 0.03, 0.02]
  },
  ancient_key: {
    name: "ancient_key",
    displayName: "Ancient Key",
    symbol: "🗝️",
    color: "text-yellow-500",
    description: "A mysterious key formed from four fragments. What secrets might it unlock?"
  }
};

export const PICKAXE_TIERS = {
  wooden: 0,
  stone: 1,
  copper: 2,
  iron: 3,
  titanium: 4,
  platinum: 5,
  tungsten: 6,
  diamond: 7,
  ice: 8,
  pickhacks: 9
} as const;

export const RESOURCE_TIERS = {
  coal: 1,
  copper_ore: 2,
  iron_ore: 3,
  titanium_ore: 4,
  platinum_ore: 5,
  tungsten_ore: 6,
  diamond: 7
} as const;

export interface Boss {
  name: string;
  displayName: string;
  health: number;
  damage: number;
  requiredLevel: number;
  requiredPickaxeTier: number;
  symbol: string;
  color: string;
  loot: {
    keyFragment?: string;
    sprAxe?: string;
  };
}

export const BOSS_ROOMS = {
  17: {
    name: "crystal_titan",
    displayName: "Crystal Titan",
    health: 300,
    damage: 25,
    requiredLevel: 14,
    requiredPickaxeTier: PICKAXE_TIERS.tungsten,
    symbol: "👾",
    color: "text-purple-500",
    loot: {
      keyFragment: "key_fragment_b",
      sprAxe: "axe_body_spraxe_fresh"
    }
  },
  18: {
    name: "ore_guardian",
    displayName: "Ore Guardian",
    health: 200,
    damage: 20,
    requiredLevel: 10,
    requiredPickaxeTier: PICKAXE_TIERS.platinum,
    symbol: "🗿",
    color: "text-gray-400",
    loot: {
      keyFragment: "key_fragment_a",
      sprAxe: "axe_body_spraxe_cool"
    }
  },
  19: {
    name: "shadow_colossus",
    displayName: "Shadow Colossus",
    health: 500,
    damage: 35,
    requiredLevel: 18,
    requiredPickaxeTier: PICKAXE_TIERS.diamond,
    symbol: "👻",
    color: "text-blue-600",
    loot: {
      keyFragment: "key_fragment_d",
      sprAxe: "axe_body_spraxe_mountain"
    }
  },
  20: {
    name: "ancient_golem",
    displayName: "Ancient Golem",
    health: 400,
    damage: 30,
    requiredLevel: 16,
    requiredPickaxeTier: PICKAXE_TIERS.tungsten,
    symbol: "🗿",
    color: "text-yellow-600",
    loot: {
      keyFragment: "key_fragment_c"
    }
  }
} as const;

export const SPECIAL_PICKAXES = {
  can_of_whoop_axe: {
    name: "can_of_whoop_axe",
    displayName: "Can of Whoop Axe",
    power: 10,
    damage: 30,
    symbol: "🛡️",
    color: "text-blue-400",
    description: "Smells like high school.",
    recipe: {
      axe_body_spraxe_fresh: 1,
      axe_body_spraxe_mountain: 1,
      axe_body_spraxe_cool: 1
    }
  }
} as const;

export const FINAL_BOSS = {
  name: "ancient_guardian",
  displayName: "Ancient Guardian",
  health: 1000,
  damage: 50,
  requiredLevel: 20,
  requiredPickaxeTier: PICKAXE_TIERS.can_of_whoop_axe,
  symbol: "👹",
  color: "text-red-600",
  description: "The legendary guardian of the ancient mines, awakened by the collection of the four key fragments.",
  loot: {
    // Special reward for beating the final boss could be added here
  }
} as const;