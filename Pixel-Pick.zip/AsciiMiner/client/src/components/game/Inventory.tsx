import { useGameState, sellResource, changePickaxe, changeArmor } from '@/lib/gameState';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RESOURCES, PICKAXES, HEALTH_ITEMS, ARMOR_ITEMS, SPECIAL_ITEMS, SPECIAL_PICKAXES } from '@/lib/gameTypes';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface InventoryProps {
  isInCave: boolean;
}

export function Inventory({ isInCave }: InventoryProps) {
  const { 
    inventory, 
    currency, 
    currentPickaxe, 
    currentArmor, 
    miningPower,
    ownedPickaxes,
    ownedArmor
  } = useGameState();

  // Include both regular pickaxes and special pickaxes
  const allPickaxes = [
    ...PICKAXES,
    ...Object.values(SPECIAL_PICKAXES)
  ];

  const currentPickaxeData = allPickaxes.find(p => p.name === currentPickaxe);
  const currentArmorData = ARMOR_ITEMS.find(a => a.name === currentArmor);

  // Helper function to check if an item is a key fragment
  const isKeyFragment = (itemName: string) => itemName.startsWith('key_fragment_');

  // Helper function to check if an item is a spr-axe component
  const isSprAxeComponent = (itemName: string) => itemName.startsWith('axe_spraxe_');

  return (
    <Card className="p-4 bg-gray-800">
      <h2 className="text-xl font-bold mb-4 text-yellow-500">Inventory</h2>

      {/* Important Items Section */}
      <div className="mb-4">
        <h3 className="text-md font-bold mb-2 text-purple-400">Important Items</h3>
        <div className="space-y-2">
          {Object.entries(inventory).map(([itemName, amount]) => {
            if (isKeyFragment(itemName)) {
              return (
                <TooltipProvider key={itemName}>
                  <Tooltip>
                    <TooltipTrigger className="w-full text-left">
                      <div className="flex items-center gap-2 p-2 bg-gray-700 rounded">
                        <span className="text-yellow-500 font-mono">🗝️ Key Fragment</span>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>A mysterious fragment of an ancient key. Collect all four to unlock something special...</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              );
            }
            if (isSprAxeComponent(itemName)) {
              return (
                <TooltipProvider key={itemName}>
                  <Tooltip>
                    <TooltipTrigger className="w-full text-left">
                      <div className="flex items-center gap-2 p-2 bg-gray-700 rounded">
                        <span className="text-blue-400 font-mono">🛡️ Spr-Axe Component</span>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>A component of the legendary Can of Whoop Axe. Collect all three to craft it.</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              );
            }
            if (itemName === 'ancient_key') {
              const specialItem = SPECIAL_ITEMS[itemName];
              return (
                <TooltipProvider key={itemName}>
                  <Tooltip>
                    <TooltipTrigger className="w-full text-left">
                      <div className="flex items-center gap-2 p-2 bg-gray-700 rounded">
                        <span className={`${specialItem.color} font-mono`}>
                          {specialItem.symbol} {specialItem.displayName}
                        </span>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{specialItem.description}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              );
            }
            return null;
          })}
        </div>
      </div>

      {/* Current Pickaxe Display */}
      <div className="mb-4">
        <label className="text-sm text-gray-400 mb-2 block">Current Pickaxe</label>
        <div className="mb-2">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger className="w-full text-left">
                <div className="flex items-center gap-2 p-2 bg-gray-700 rounded">
                  <span className={`${currentPickaxeData?.color} font-mono`}>
                    {currentPickaxeData?.symbol}
                  </span>
                  <span className="text-gray-200">
                    {currentPickaxeData?.displayName} (Mining Power: {miningPower})
                  </span>
                </div>
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <p>{currentPickaxeData?.description}</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        <Select value={currentPickaxe} onValueChange={changePickaxe}>
          <SelectTrigger className="w-full bg-gray-700">
            <SelectValue>Change Pickaxe</SelectValue>
          </SelectTrigger>
          <SelectContent>
            {ownedPickaxes.map(pickaxeName => {
              const pickaxe = allPickaxes.find(p => p.name === pickaxeName);
              if (!pickaxe) return null;
              return (
                <TooltipProvider key={pickaxe.name}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <SelectItem value={pickaxe.name}>
                        <div className="flex items-center gap-2">
                          <span className={`${pickaxe.color} font-mono`}>
                            {pickaxe.symbol}
                          </span>
                          <span>
                            {pickaxe.displayName} (Power: {pickaxe.power})
                          </span>
                        </div>
                      </SelectItem>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{pickaxe.description}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              );
            })}
          </SelectContent>
        </Select>
      </div>

      {/* Current Armor Display */}
      <div className="mb-4">
        <label className="text-sm text-gray-400 mb-2 block">Current Armor</label>
        {currentArmorData && (
          <div className="mb-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger className="w-full text-left">
                  <div className="flex items-center gap-2 p-2 bg-gray-700 rounded">
                    <span className={`${currentArmorData.color} font-mono`}>
                      {currentArmorData.symbol}
                    </span>
                    <span className="text-gray-200">
                      {currentArmorData.displayName} (Defense: {currentArmorData.defense})
                    </span>
                  </div>
                </TooltipTrigger>
                <TooltipContent className="max-w-sm">
                  <p>{currentArmorData.description}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        )}

        <Select
          value={currentArmor || "none"}
          onValueChange={value => changeArmor(value === "none" ? null : value)}
        >
          <SelectTrigger className="w-full bg-gray-700">
            <SelectValue>Change Armor</SelectValue>
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">
              <span className="text-gray-400">No Armor</span>
            </SelectItem>
            {ownedArmor.map(armorName => {
              const armor = ARMOR_ITEMS.find(a => a.name === armorName);
              if (!armor) return null;
              return (
                <TooltipProvider key={armor.name}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <SelectItem value={armor.name}>
                        <div className="flex items-center gap-2">
                          <span className={`${armor.color} font-mono`}>
                            {armor.symbol}
                          </span>
                          <span>
                            {armor.displayName} (Defense: {armor.defense})
                          </span>
                        </div>
                      </SelectItem>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{armor.description}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              );
            })}
          </SelectContent>
        </Select>
      </div>

      <div className="mb-4">
        <span className="text-yellow-400">Currency: {currency} 💰</span>
      </div>

      {/* Special Items */}
      <div className="mb-4">
        <h3 className="text-md font-bold mb-2 text-gray-200">Special Items</h3>
        {Object.entries(inventory).map(([itemName, amount]) => {
          const specialItem = SPECIAL_ITEMS[itemName];
          if (!specialItem || isKeyFragment(itemName) || isSprAxeComponent(itemName) || itemName === 'ancient_key') return null;

          return (
            <div key={itemName} className="mb-4">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger className="w-full text-left">
                    <div className="flex items-center justify-between p-2 bg-gray-700 rounded">
                      <span className={`${specialItem.color} font-mono`}>
                        {specialItem.symbol} {specialItem.displayName}
                      </span>
                      {itemName === 'cave_map' && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" className="text-yellow-400 hover:text-yellow-300">
                              View Map
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-gray-800 text-white">
                            <DialogHeader>
                              <DialogTitle className="text-yellow-500">Cave Map</DialogTitle>
                            </DialogHeader>
                            <pre className="font-mono text-xs sm:text-sm whitespace-pre text-gray-300">
                              {specialItem.mapArt}
                            </pre>
                          </DialogContent>
                        </Dialog>
                      )}
                    </div>
                  </TooltipTrigger>
                  <TooltipContent className="max-w-sm">
                    <p>{specialItem.description}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          );
        })}
      </div>

      {/* Health Items */}
      <div className="mb-4">
        <h3 className="text-md font-bold mb-2 text-red-400">Health Items</h3>
        <div className="space-y-2">
          {Object.entries(inventory).map(([itemName, amount]) => {
            const healthItem = HEALTH_ITEMS.find(h => h.name === itemName);
            if (!healthItem) return null;

            return (
              <TooltipProvider key={itemName}>
                <Tooltip>
                  <TooltipTrigger className="w-full text-left">
                    <div className="flex items-center justify-between p-2 bg-gray-700 rounded">
                      <span className={`${healthItem.color} font-mono`}>
                        {healthItem.symbol} {healthItem.displayName} (Heal: {healthItem.healAmount}): {String(amount)}
                      </span>
                    </div>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Restores {healthItem.healAmount} health points when used.</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            );
          })}
        </div>
      </div>

      {/* Resources */}
      <div className="space-y-2">
        <h3 className="text-md font-bold mb-2 text-gray-200">Resources</h3>
        {Object.entries(inventory).map(([resource, amount]) => {
          const resourceData = RESOURCES.find((r) => r.name === resource);
          if (!resourceData) return null;

          return (
            <div
              key={resource}
              className="flex items-center justify-between p-2 bg-gray-700 rounded"
            >
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger className="text-left">
                    <span className={`${resourceData.color} font-mono`}>
                      {resourceData.symbol} {resourceData.displayName}: {String(amount)}
                    </span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Value: {resourceData.value} coins each</p>
                    <p>Required Mining Power: {resourceData.requiredPower}</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
              {!isInCave && (
                <Button
                  onClick={() => sellResource(resource)}
                  size="sm"
                  variant="outline"
                  className="text-green-400 hover:text-green-300"
                >
                  Sell
                </Button>
              )}
            </div>
          );
        })}
      </div>
    </Card>
  );
}