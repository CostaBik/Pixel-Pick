import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useGameState } from '@/lib/gameState';

interface VictoryScreenProps {
  onClose: () => void;
}

export function VictoryScreen({ onClose }: VictoryScreenProps) {
  const { totalMined, enemiesDefeated, deaths } = useGameState();

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
      <Card className="max-w-2xl w-full bg-gray-800 p-6">
        <pre className="font-mono text-center mb-6 whitespace-pre text-yellow-500">
{`
    🏆 VICTORY! 🏆
 ==================
    ⛏️ 🦺 ⛏️
  JOE MINER WINS!
 ==================
   🖨️ 🖨️ 🖨️ 🖨️
 3D Printers Saved!
`}
        </pre>
        <div className="text-center mb-6 space-y-4">
          <h2 className="text-2xl font-bold text-yellow-500">
            Congratulations, Legendary Splunker!
          </h2>
          <p className="text-gray-300">
            You have defeated the Ancient Guardian and recovered all four 3D printers!
            Your name will be forever remembered in the halls of McNutt.
          </p>
          <div className="space-y-2 text-gray-400">
            <p>Final Stats:</p>
            <p>Total Blocks Mined: {totalMined}</p>
            <p>Enemies Defeated: {enemiesDefeated}</p>
            <p>Deaths: {deaths}</p>
          </div>
        </div>
        <div className="flex justify-center">
          <Button
            onClick={onClose}
            className="bg-yellow-600 hover:bg-yellow-700"
          >
            Continue Adventure
          </Button>
        </div>
      </Card>
    </div>
  );
}
