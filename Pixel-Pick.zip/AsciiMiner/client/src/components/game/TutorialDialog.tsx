import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface TutorialDialogProps {
  onClose: () => void;
}

export function TutorialDialog({ onClose }: TutorialDialogProps) {
  const [step, setStep] = useState(0);
  const [showTutorial, setShowTutorial] = useState(true);

  const tutorialSteps = [
    {
      title: "Welcome to PIXEL PICK!",
      content: "In this game you will navigate through caverns, mining ores, buying and crafting gear, and fighting monsters."
    },
    {
      title: "How to Play",
      content: "To play, you must enter the cave and mine for ore, which in turn can be sold for currency, or combined together to create Pickaxes and Armor, which is necessary in your fight against the Ore Monsters. Leveling up and acquiring new weapons allows you to increase your power in battle and your ability to mine increasingly valuable materials."
    },
    {
      title: "Final Words",
      content: "Embark on your journey into the mines, conquering enemies and getting rich while doing it. Good luck and have fun!"
    }
  ];

  const handleSkip = () => {
    setShowTutorial(false);
    onClose();
  };

  const handleNext = () => {
    if (step < tutorialSteps.length - 1) {
      setStep(step + 1);
    } else {
      setShowTutorial(false);
      onClose();
    }
  };

  return (
    <Dialog open={showTutorial} onOpenChange={setShowTutorial}>
      <DialogContent className="sm:max-w-[425px] bg-gray-800 text-white">
        <DialogHeader>
          <DialogTitle className="text-xl text-yellow-500">
            {tutorialSteps[step].title}
          </DialogTitle>
          <DialogDescription className="text-gray-300">
            {tutorialSteps[step].content}
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex justify-between">
          {step === 0 && (
            <>
              <Button variant="outline" onClick={handleSkip}>
                Skip Tutorial
              </Button>
              <Button className="bg-yellow-600 hover:bg-yellow-700" onClick={handleNext}>
                Next
              </Button>
            </>
          )}
          {step > 0 && step < tutorialSteps.length - 1 && (
            <Button className="bg-yellow-600 hover:bg-yellow-700" onClick={handleNext}>
              Next
            </Button>
          )}
          {step === tutorialSteps.length - 1 && (
            <Button className="bg-yellow-600 hover:bg-yellow-700" onClick={handleNext}>
              End Tutorial
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
