import { useGameState, buyPickaxe, buyHealthItem, buyArmor } from '@/lib/gameState';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { SHOP_PICKAXES, HEALTH_ITEMS, SHOP_ARMOR } from '@/lib/gameTypes';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function Shop() {
  const { currency, currentPickaxe, currentArmor } = useGameState();

  return (
    <Card className="p-4 bg-gray-800">
      <h2 className="text-xl font-bold mb-4 text-yellow-500">Miner Tweaks Shop</h2>
      <Tabs defaultValue="pickaxes">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pickaxes">Pickaxes</TabsTrigger>
          <TabsTrigger value="health">Health Items</TabsTrigger>
          <TabsTrigger value="armor">Armor</TabsTrigger>
        </TabsList>

        {/* Pickaxes Tab */}
        <TabsContent value="pickaxes" className="space-y-2">
          {SHOP_PICKAXES.map((pickaxe) => (
            <div
              key={pickaxe.name}
              className="flex items-center justify-between p-2 bg-gray-700 rounded"
            >
              <div className="flex items-center gap-2">
                <span className={`${pickaxe.color} font-mono`}>
                  {pickaxe.symbol}
                </span>
                <span className="text-gray-200">
                  {pickaxe.displayName} (Power: {pickaxe.power}, Damage: {Math.floor(pickaxe.power * 2)})
                </span>
              </div>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    disabled={
                      currency < (pickaxe.cost ?? 0) || currentPickaxe === pickaxe.name
                    }
                    size="sm"
                    variant="outline"
                    className="text-blue-400 hover:text-blue-300"
                  >
                    {pickaxe.cost} 💰
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Purchase</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to buy this pickaxe?
                      (This will convert your mining power to the selected pickaxe.)
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => buyPickaxe(pickaxe.name)}>
                      Buy
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          ))}
        </TabsContent>

        {/* Health Items Tab */}
        <TabsContent value="health" className="space-y-2">
          {HEALTH_ITEMS.map((item) => (
            <div
              key={item.name}
              className="flex items-center justify-between p-2 bg-gray-700 rounded"
            >
              <div className="flex items-center gap-2">
                <span className={`${item.color} font-mono`}>
                  {item.symbol}
                </span>
                <span className="text-gray-200">
                  {item.displayName} (Heal: {item.healAmount})
                </span>
              </div>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    disabled={currency < item.cost}
                    size="sm"
                    variant="outline"
                    className="text-red-400 hover:text-red-300"
                  >
                    {item.cost} 💰
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Purchase</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to buy this health potion?
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => buyHealthItem(item.name)}>
                      Buy
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          ))}
        </TabsContent>

        {/* Armor Tab */}
        <TabsContent value="armor" className="space-y-2">
          {SHOP_ARMOR.map((armor) => (
            <div
              key={armor.name}
              className="flex items-center justify-between p-2 bg-gray-700 rounded"
            >
              <div className="flex items-center gap-2">
                <span className={`${armor.color} font-mono`}>
                  {armor.symbol}
                </span>
                <span className="text-gray-200">
                  {armor.displayName} (Defense: {armor.defense})
                </span>
              </div>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    disabled={
                      currency < (armor.cost ?? 0) || currentArmor === armor.name
                    }
                    size="sm"
                    variant="outline"
                    className="text-blue-400 hover:text-blue-300"
                  >
                    {armor.cost} 💰
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Purchase</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to buy this armor?
                      (This will replace your current armor if you have any.)
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => buyArmor(armor.name)}>
                      Buy
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          ))}
        </TabsContent>
      </Tabs>
    </Card>
  );
}