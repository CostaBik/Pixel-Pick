import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  CAVE_ENTRANCE, CAVE_RIDDLE, LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4, LEVEL_5, LEVEL_6,
  LEVEL_7, LEVEL_8, LEVEL_9, LEVEL_10, LEVEL_11, LEVEL_12, LEVEL_13, LEVEL_14,
  LEVEL_15, LEVEL_16, LEVEL_17, LEVEL_18, LEVEL_19, LEVEL_20, MINING_ANIMATION
} from '@/lib/ascii';
import { mine, useGameState, startCombat, exitCave } from '@/lib/gameState';
import { MONSTERS, LEVEL_MONSTERS } from '@/lib/monsterTypes';
import { CombatEncounter } from './CombatEncounter';
import { BOSS_ROOMS, PICKAXE_TIERS, FINAL_BOSS } from '@/lib/gameTypes';
import { toast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface MiningAreaProps {
  isInCave: boolean;
  setIsInCave: (value: boolean) => void;
  onExitCave: () => void;
  onPlayerDeath: () => void;
  isInFinalBoss: boolean;
  setIsInFinalBoss: (value: boolean) => void;
}

export function MiningArea({
  isInCave,
  setIsInCave,
  onExitCave,
  onPlayerDeath,
  isInFinalBoss,
  setIsInFinalBoss
}: MiningAreaProps) {
  const [animationFrame, setAnimationFrame] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [caveDepth, setCaveDepth] = useState(0);
  const state = useGameState();
  const { activeMonster, level, currentPickaxe } = state;


  const handleMine = () => {
    if (isInFinalBoss) {
      startCombat({
        id: FINAL_BOSS.name,
        name: FINAL_BOSS.name,
        displayName: FINAL_BOSS.displayName,
        health: FINAL_BOSS.health,
        damage: FINAL_BOSS.damage,
        symbol: FINAL_BOSS.symbol,
        color: FINAL_BOSS.color,
        description: FINAL_BOSS.description,
        mineralDrops: FINAL_BOSS.loot
      });
      return;
    }

    if (caveDepth >= 17 && caveDepth <= 20) {
      const boss = BOSS_ROOMS[caveDepth as keyof typeof BOSS_ROOMS];
      if (!boss) return;

      if (level < boss.requiredLevel) {
        toast({
          description: `Warning: This boss is recommended for level ${boss.requiredLevel}+ miners. Proceed with caution!`,
          duration: 3000
        });
      }

      const currentPickaxeTier = PICKAXE_TIERS[currentPickaxe as keyof typeof PICKAXE_TIERS];
      if (currentPickaxeTier < boss.requiredPickaxeTier) {
        toast({
          description: `Warning: A stronger pickaxe is recommended for this fight. You might have trouble dealing damage!`,
          duration: 3000
        });
      }

      startCombat({
        id: boss.name,
        name: boss.name,
        displayName: boss.displayName,
        health: boss.health,
        damage: boss.damage,
        symbol: boss.symbol,
        color: boss.color,
        description: `A powerful boss that guards this area`,
        mineralDrops: {
          ...(boss.loot.keyFragment ? { [boss.loot.keyFragment]: 1 } : {}),
          ...(boss.loot.sprAxe ? { [boss.loot.sprAxe]: 1 } : {})
        }
      });
      return;
    }

    setIsAnimating(true);

    const monsterChance = Math.random();
    if (caveDepth > 0 && monsterChance < 0.15) {
      const possibleMonsters = LEVEL_MONSTERS[caveDepth] || [];
      if (possibleMonsters.length > 0) {
        const monsterType = possibleMonsters[Math.floor(Math.random() * possibleMonsters.length)];
        const monster = MONSTERS.find(m => m.name === monsterType);
        if (monster) {
          startCombat({ ...monster });
          setIsAnimating(false);
          return;
        }
      }
    }

    mine();
    setTimeout(() => setIsAnimating(false), 500);
  };

  useEffect(() => {
    if (isAnimating) {
      const interval = setInterval(() => {
        setAnimationFrame((prev) => (prev + 1) % MINING_ANIMATION.length);
      }, 150);
      return () => clearInterval(interval);
    } else {
      setAnimationFrame(0);
    }
  }, [isAnimating]);

  const handleExitCave = () => {
    exitCave();
    setIsInCave(false);
    setCaveDepth(0);
    onExitCave();
  };

  const handleCombatFlee = () => {
    onPlayerDeath();
    handleExitCave();
  };

  const handleExitBoss = () => {
    setIsInFinalBoss(false);
  };

  const CaveEntrance = () => (
    <>
      <div className="bg-gray-800 rounded p-4 mb-4 overflow-x-auto">
        <pre className="font-mono text-xs sm:text-sm md:text-base text-center text-white whitespace-pre">
          {CAVE_ENTRANCE}
        </pre>
      </div>
      <div className="flex justify-center gap-4">
        <Dialog>
          <DialogTrigger asChild>
            <Button
              variant="outline"
              className="text-yellow-500 hover:text-yellow-400"
            >
              Read Ancient Sign
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-gray-800 text-white">
            <DialogHeader>
              <DialogTitle className="text-yellow-500">Ancient Riddle</DialogTitle>
            </DialogHeader>
            <pre className="font-mono text-sm whitespace-pre text-gray-300">
              {CAVE_RIDDLE}
            </pre>
          </DialogContent>
        </Dialog>
        <Button
          onClick={() => {
            setIsInCave(true);
            setCaveDepth(1);
          }}
          className="bg-yellow-600 hover:bg-yellow-700"
        >
          Enter Cave
        </Button>
      </div>
    </>
  );

  const CaveInterior = () => {
    const animation = MINING_ANIMATION[animationFrame].split('\n');
    let caveScene;
    switch (caveDepth) {
      case 1:
        caveScene = LEVEL_1;
        break;
      case 2:
        caveScene = LEVEL_2;
        break;
      case 3:
        caveScene = LEVEL_3;
        break;
      case 4:
        caveScene = LEVEL_4;
        break;
      case 5:
        caveScene = LEVEL_5;
        break;
      case 6:
        caveScene = LEVEL_6;
        break;
      case 7:
        caveScene = LEVEL_7;
        break;
      case 8:
        caveScene = LEVEL_8;
        break;
      case 9:
        caveScene = LEVEL_9;
        break;
      case 10:
        caveScene = LEVEL_10;
        break;
      case 11:
        caveScene = LEVEL_11;
        break;
      case 12:
        caveScene = LEVEL_12;
        break;
      case 13:
        caveScene = LEVEL_13;
        break;
      case 14:
        caveScene = LEVEL_14;
        break;
      case 15:
        caveScene = LEVEL_15;
        break;
      case 16:
        caveScene = LEVEL_16;
        break;
      case 17:
        caveScene = LEVEL_17;
        break;
      case 18:
        caveScene = LEVEL_18;
        break;
      case 19:
        caveScene = LEVEL_19;
        break;
      case 20:
        caveScene = LEVEL_20;
        break;
      default:
        caveScene = LEVEL_1;
    }

    caveScene = caveScene
      .replace('%PLAYER%', animation[0])
      .replace('%PLAYER2%', animation[1])
      .replace('%PLAYER3%', animation[2]);

    return (
      <>
        <div className="bg-gray-800 rounded p-4 mb-4 overflow-x-auto">
          <pre className="font-mono text-xs sm:text-sm md:text-base text-center text-white whitespace-pre">
            {caveScene}
          </pre>
        </div>
        <div className="flex justify-center gap-4">
          <Button
            onClick={handleMine}
            disabled={isAnimating}
            className="bg-yellow-600 hover:bg-yellow-700"
          >
            Mine!
          </Button>
          {caveDepth === 1 && (
            <Button
              onClick={() => setCaveDepth(2)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 2 && (
            <>
              <Button
                onClick={() => setCaveDepth(3)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Proceed Left
              </Button>
              <Button
                onClick={() => setCaveDepth(4)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Proceed Right
              </Button>
            </>
          )}
          {caveDepth === 3 && (
            <Button
              onClick={() => setCaveDepth(5)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 4 && (
            <Button
              onClick={() => setCaveDepth(6)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 5 && (
            <Button
              onClick={() => setCaveDepth(7)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 6 && (
            <Button
              onClick={() => setCaveDepth(8)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 7 && (
            <>
              <Button
                onClick={() => setCaveDepth(9)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Proceed Left
              </Button>
              <Button
                onClick={() => setCaveDepth(10)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Proceed Right
              </Button>
            </>
          )}
          {caveDepth === 8 && (
            <>
              <Button
                onClick={() => setCaveDepth(11)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Proceed Left
              </Button>
              <Button
                onClick={() => setCaveDepth(12)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Proceed Right
              </Button>
            </>
          )}
          {caveDepth === 9 && (
            <Button
              onClick={() => setCaveDepth(13)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 10 && (
            <Button
              onClick={() => setCaveDepth(14)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 11 && (
            <Button
              onClick={() => setCaveDepth(15)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 12 && (
            <Button
              onClick={() => setCaveDepth(16)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 13 && (
            <Button
              onClick={() => setCaveDepth(17)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 14 && (
            <Button
              onClick={() => setCaveDepth(18)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 15 && (
            <Button
              onClick={() => setCaveDepth(19)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          {caveDepth === 16 && (
            <Button
              onClick={() => setCaveDepth(20)}
              className="bg-purple-600 hover:bg-purple-700"
            >
              Proceed Further
            </Button>
          )}
          <Button
            onClick={handleExitCave}
            variant="outline"
            className="text-gray-300"
          >
            {caveDepth > 1 ? "Return to Surface" : "Exit Cave"}
          </Button>
        </div>
      </>
    );
  };

  return (
    <Card className="p-4 bg-gray-900">
      {isInCave ? (
        activeMonster ? (
          <CombatEncounter onFlee={handleCombatFlee} />
        ) : (
          <CaveInterior />
        )
      ) : isInFinalBoss ? (
        activeMonster ? (
          <CombatEncounter onFlee={handleExitBoss} />
        ) : (
          <div className="bg-gray-800 rounded p-4 mb-4">
            <pre className="font-mono text-xs sm:text-sm md:text-base text-center text-red-500 whitespace-pre">
              {`
                🏛️ Ancient Chamber 🏛️
                The air crackles with ancient power...
                ${FINAL_BOSS.symbol} The Ancient Guardian awaits...
              `}
            </pre>
            <div className="flex justify-center gap-4 mt-4">
              <Button
                onClick={handleMine}
                className="bg-red-600 hover:bg-red-700"
              >
                Challenge Boss
              </Button>
              <Button
                onClick={handleExitBoss}
                variant="outline"
                className="text-gray-300"
              >
                Retreat
              </Button>
            </div>
          </div>
        )
      ) : (
        <CaveEntrance />
      )}
    </Card>
  );
}