import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface CraftingAvailableDialogProps {
  onClose: () => void;
}

export function CraftingAvailableDialog({ onClose }: CraftingAvailableDialogProps) {
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-gray-800 text-white">
        <DialogHeader>
          <DialogTitle className="text-xl text-purple-500">
            Crafting Available!
          </DialogTitle>
          <DialogDescription className="text-gray-300">
            You now have enough materials to craft better equipment! 
            Visit the crafting menu to forge stronger pickaxes and enhance your mining abilities.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button className="bg-purple-600 hover:bg-purple-700" onClick={onClose}>
            Let's Craft!
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
