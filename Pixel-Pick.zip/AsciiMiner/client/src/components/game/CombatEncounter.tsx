import { useGameState, attackMonster, useHealthItem } from '@/lib/gameState';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MONSTERS } from '@/lib/monsterTypes';
import { HEALTH_ITEMS } from '@/lib/gameTypes';

interface CombatEncounterProps {
  onFlee: () => void;
}

export function CombatEncounter({ onFlee }: CombatEncounterProps) {
  const { activeMonster, playerHealth, playerMaxHealth, playerDamage, inventory } = useGameState();

  if (!activeMonster) return null;

  const handleAttack = async () => {
    const died = await attackMonster();
    if (died) {
      onFlee(); // Exit cave if player died
    }
  };

  const handleFlee = async () => {
    // 60% chance to successfully flee
    const fleeSuccess = Math.random() < 0.6;

    if (fleeSuccess) {
      onFlee(); // Successfully fled
    } else {
      // Failed to flee, player dies
      useGameState.setState(state => ({
        playerHealth: state.playerMaxHealth, // Restore to max health instead of 0
        inventory: {},
        activeMonster: null,
        deaths: state.deaths + 1,
        totalDamageTaken: state.totalDamageTaken + playerHealth // Count remaining health as damage taken
      }));
      onFlee(); // Exit cave after death
    }
  };

  // Get available health potions from inventory
  const availableHealthItems = Object.entries(inventory)
    .filter(([itemName]) => HEALTH_ITEMS.find(h => h.name === itemName))
    .map(([itemName, amount]) => ({
      item: HEALTH_ITEMS.find(h => h.name === itemName)!,
      amount
    }));

  return (
    <Card className="p-4 bg-gray-800 text-white">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h2 className="text-xl font-bold mb-2">Combat!</h2>
          <p className="text-sm mb-1">Your Health: {playerHealth}/{playerMaxHealth}</p>
          <p className="text-sm">Your Damage: {playerDamage}</p>
        </div>
        <div className="text-right">
          <span className={`${activeMonster.color} text-4xl font-mono`}>
            {activeMonster.symbol}
          </span>
          <h3 className="text-lg font-bold">{activeMonster.displayName}</h3>
          <p className="text-sm">Health: {activeMonster.health}</p>
          <p className="text-sm">Damage: {activeMonster.damage}</p>
        </div>
      </div>

      <p className="text-sm mb-4 text-gray-300">{activeMonster.description}</p>

      <div className="flex flex-wrap gap-2 justify-center">
        <Button
          onClick={handleAttack}
          className="bg-red-600 hover:bg-red-700"
        >
          Attack!
        </Button>

        {/* Health Potions */}
        {availableHealthItems.map(({ item, amount }) => (
          <Button
            key={item.name}
            onClick={() => useHealthItem(item.name)}
            className="bg-green-600 hover:bg-green-700"
            disabled={playerHealth >= playerMaxHealth}
          >
            Use {item.displayName} ({amount})
          </Button>
        ))}

        <Button
          onClick={handleFlee}
          variant="outline"
          className="text-gray-300"
          title="60% chance to flee successfully, 40% chance to die while fleeing"
        >
          Try to Flee
        </Button>
      </div>
    </Card>
  );
}