import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface ShopIntroDialogProps {
  onClose: () => void;
  isDeath?: boolean;
}

export function ShopIntroDialog({ onClose, isDeath = false }: ShopIntroDialogProps) {
  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px] bg-gray-800 text-white">
        <DialogHeader>
          <DialogTitle className="text-xl text-yellow-500">
            Greeting Splunker!
          </DialogTitle>
          <DialogDescription className="text-gray-300">
            {isDeath ? (
              "The mines can prove to be a dangerous place if ill-prepared, the shop is now available for you to help gear yourself up. Here you can purchase whatever you might need for your adventures! We offer a variety of different Pickaxes, Health Items, and Armor."
            ) : (
              "The shop is now available for you, to help on your journey's into the mine. Here you can purchase whatever you might need for your adventures! We offer a variety of different Pickaxes, Health Items, and Armor."
            )}
            <div className="mt-2">
              Here is 100 💰 to start your shopping. Good luck out there!
            </div>
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button className="bg-yellow-600 hover:bg-yellow-700" onClick={onClose}>
            Let's Shop!
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}