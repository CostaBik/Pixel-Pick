import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface CutsceneProps {
  onComplete: () => void;
}

const CUTSCENE_FRAMES = [
  {
    text: `In the bustling halls of Missouri S&T's McNutt Hall,
four state-of-the-art 3D printers worked tirelessly,
bringing students' visions to life...`,
    ascii: `
    🏛️ McNutt Hall 🏛️
    ==================
    |  🖨️ 🖨️ 🖨️ 🖨️  |
    |  3D Printers   |
    ==================
    `
  },
  {
    text: `But one fateful night, the Ancient Guardian,
a mythical being from deep within the mines,
emerged from the depths...`,
    ascii: `
         👹
    /=============\\
    |    Mine     |
    |   Entrance  |
    \\=============/
    `
  },
  {
    text: `With its fearsome minions, the Ancient Guardian
stole the precious 3D printers, retreating deep
into the treacherous caves below...`,
    ascii: `
      👹
    🤖 🖨️ 🤖
    🤖 🖨️ 🤖
       ⬇️
    /=========\\
    |   Mine  |
    \\=========/
    `
  },
  {
    text: `Now, only one brave soul can recover these precious machines.
Joe Miner, S&T's legendary mascot, must venture into the depths,
face the dangers that await, and become the most legendary splunker
in the lands...`,
    ascii: `
        ⛏️
      🦺 Joe Miner
    /==============\\
    |    Ready?    |
    \\==============/
    `
  }
];

export function Cutscene({ onComplete }: CutsceneProps) {
  const [currentFrame, setCurrentFrame] = useState(0);

  const handleNext = () => {
    if (currentFrame < CUTSCENE_FRAMES.length - 1) {
      setCurrentFrame(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        handleNext();
      }
    };
    window.addEventListener('keypress', handleKeyPress);
    return () => window.removeEventListener('keypress', handleKeyPress);
  }, [currentFrame]);

  const frame = CUTSCENE_FRAMES[currentFrame];

  return (
    <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full bg-gray-800 p-6">
        <pre className="font-mono text-center mb-6 whitespace-pre text-yellow-500">
          {frame.ascii}
        </pre>
        <div className="text-center mb-6 space-y-2">
          {frame.text.split('\n').map((line, i) => (
            <p key={i} className="text-gray-300">{line}</p>
          ))}
        </div>
        <div className="flex justify-center">
          <Button
            onClick={handleNext}
            className="bg-yellow-600 hover:bg-yellow-700"
          >
            {currentFrame < CUTSCENE_FRAMES.length - 1 ? 'Continue' : 'Begin Adventure'}
          </Button>
        </div>
        <p className="text-center text-gray-500 mt-4 text-sm">
          Press SPACE or ENTER to continue
        </p>
      </Card>
    </div>
  );
}
