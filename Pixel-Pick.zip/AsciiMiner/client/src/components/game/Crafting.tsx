import { useGameState } from '@/lib/gameState';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CRAFTABLE_PICKAXES, CRAFTABLE_ARMOR, RESOURCES, SPECIAL_PICKAXES } from '@/lib/gameTypes';
import { craftPickaxe, craftArmor } from '@/lib/gameState';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function Crafting() {
  const { inventory, currentPickaxe, currentArmor } = useGameState();

  const canCraft = (recipe: Record<string, number>) => {
    return Object.entries(recipe).every(
      ([item, amount]) => (inventory[item] ?? 0) >= amount
    );
  };

  const getResourceDisplayName = (resourceName: string) => {
    const resource = RESOURCES.find(r => r.name === resourceName);
    return resource ? resource.displayName : resourceName;
  };

  const canCraftSpecialPickaxe = () => {
    const hasAllSprAxes = Object.entries(SPECIAL_PICKAXES.can_of_whoop_axe.recipe).every(
      ([item, amount]) => (inventory[item] ?? 0) >= amount
    );
    return hasAllSprAxes;
  };

  return (
    <Card className="p-4 bg-gray-800">
      <h2 className="text-xl font-bold mb-4 text-purple-500">Crafting</h2>
      <Tabs defaultValue="pickaxes">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pickaxes">Pickaxes</TabsTrigger>
          <TabsTrigger value="armor">Armor</TabsTrigger>
        </TabsList>

        {/* Pickaxes Tab */}
        <TabsContent value="pickaxes" className="space-y-2">
          {CRAFTABLE_PICKAXES.map((pickaxe) => {
            const hasRequirements = canCraft(pickaxe.recipe ?? {});

            return (
              <div
                key={pickaxe.name}
                className="flex flex-col p-2 bg-gray-700 rounded"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`${pickaxe.color} font-mono`}>
                      {pickaxe.symbol}
                    </span>
                    <span className="text-gray-200">
                      {pickaxe.displayName} (Power: {pickaxe.power}, Damage: {Math.floor(pickaxe.power * 2)})
                    </span>
                  </div>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        disabled={!hasRequirements || currentPickaxe === pickaxe.name}
                        size="sm"
                        variant="outline"
                        className="text-purple-400 hover:text-purple-300"
                      >
                        Craft
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Confirm Crafting</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to craft this pickaxe?
                          (This will convert your mining power to the selected pickaxe.)
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => craftPickaxe(pickaxe.name)}>
                          Craft
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
                <div className="mt-2 text-sm text-gray-400">
                  Requirements:
                  {Object.entries(pickaxe.recipe ?? {}).map(([item, amount]) => (
                    <span
                      key={item}
                      className={`ml-2 ${
                        (inventory[item] ?? 0) >= amount
                          ? "text-green-400"
                          : "text-red-400"
                      }`}
                    >
                      {getResourceDisplayName(item)}: {inventory[item] ?? 0}/{amount}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </TabsContent>

        {/* Special Pickaxe */}
        {canCraftSpecialPickaxe() && (
          <div className="flex flex-col p-2 bg-gray-700 rounded">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className={`${SPECIAL_PICKAXES.can_of_whoop_axe.color} font-mono`}>
                  {SPECIAL_PICKAXES.can_of_whoop_axe.symbol}
                </span>
                <span className="text-gray-200">
                  {SPECIAL_PICKAXES.can_of_whoop_axe.displayName} 
                  (Power: {SPECIAL_PICKAXES.can_of_whoop_axe.power}, 
                  Damage: {SPECIAL_PICKAXES.can_of_whoop_axe.damage})
                </span>
              </div>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-purple-400 hover:text-purple-300"
                  >
                    Craft
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Craft Special Pickaxe</AlertDialogTitle>
                    <AlertDialogDescription>
                      Are you sure you want to combine your Axe Body Spr-axes into the legendary Can of Whoop Axe?
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => craftPickaxe('can_of_whoop_axe')}>
                      Craft
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        )}


        {/* Armor Tab */}
        <TabsContent value="armor" className="space-y-2">
          {CRAFTABLE_ARMOR.map((armor) => {
            const hasRequirements = canCraft(armor.recipe ?? {});

            return (
              <div
                key={armor.name}
                className="flex flex-col p-2 bg-gray-700 rounded"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className={`${armor.color} font-mono`}>
                      {armor.symbol}
                    </span>
                    <span className="text-gray-200">
                      {armor.displayName} (Defense: {armor.defense})
                    </span>
                  </div>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button
                        disabled={!hasRequirements || currentArmor === armor.name}
                        size="sm"
                        variant="outline"
                        className="text-purple-400 hover:text-purple-300"
                      >
                        Craft
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Confirm Crafting</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to craft this armor?
                          (This will replace your current armor if you have any.)
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => craftArmor(armor.name)}>
                          Craft
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
                <div className="mt-2 text-sm text-gray-400">
                  Requirements:
                  {Object.entries(armor.recipe ?? {}).map(([item, amount]) => (
                    <span
                      key={item}
                      className={`ml-2 ${
                        (inventory[item] ?? 0) >= amount
                          ? "text-green-400"
                          : "text-red-400"
                      }`}
                    >
                      {getResourceDisplayName(item)}: {inventory[item] ?? 0}/{amount}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </TabsContent>
      </Tabs>
    </Card>
  );
}