import { useGameState } from '@/lib/gameState';
import { Card } from '@/components/ui/card';

const getRequiredExp = (level: number): number => {
  if (level <= 5) return 250;
  if (level <= 10) return 500;
  if (level <= 15) return 750;
  return 1000;
};

export function Stats() {
  const {
    playerHealth,
    playerMaxHealth,
    totalMined,
    totalOreCollected,
    enemiesDefeated,
    currencySpent,
    deaths,
    totalDamageTaken,
    level,
    experience
  } = useGameState();

  const requiredExp = getRequiredExp(level);

  return (
    <Card className="p-4 bg-gray-800">
      <h2 className="text-xl font-bold mb-4 text-blue-500">Player Stats</h2>
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Level:</span>
          <span className="text-purple-400">{level} ⭐</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Experience:</span>
          <span className="text-yellow-400">{experience}/{requiredExp} ✨</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Health:</span>
          <span className="text-red-400">{playerHealth}/{playerMaxHealth} ❤️</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Times Mined:</span>
          <span className="text-yellow-400">{totalMined} ⛏️</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Total Ore Collected:</span>
          <span className="text-green-400">{totalOreCollected} 💎</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Enemies Defeated:</span>
          <span className="text-purple-400">{enemiesDefeated} ⚔️</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Currency Spent:</span>
          <span className="text-yellow-400">{currencySpent} 💰</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Deaths:</span>
          <span className="text-red-400">{deaths} 💀</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Total Damage Taken:</span>
          <span className="text-orange-400">{totalDamageTaken} 🛡️</span>
        </div>
      </div>
    </Card>
  );
}