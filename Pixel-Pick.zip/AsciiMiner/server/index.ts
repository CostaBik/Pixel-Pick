import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Set proper MIME types
app.use((req, res, next) => {
  if (req.url.endsWith('.js')) {
    res.type('application/javascript');
  } else if (req.url.endsWith('.mjs')) {
    res.type('application/javascript');
  }
  next();
});

// Add timing information to request logging
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      log(logLine);
    }
  });

  next();
});

const startServer = async (retries = 3, startPort = 5000) => {
  for (let port = startPort; port < startPort + retries; port++) {
    try {
      console.time('Total startup');
      log('Starting server initialization...');

      console.time('Routes registration');
      const server = await registerRoutes(app);
      console.timeEnd('Routes registration');

      app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
        const status = err.status || err.statusCode || 500;
        const message = err.message || "Internal Server Error";
        res.status(status).json({ message });
        console.error('Server error:', err);
      });

      // In Replit, we want to use Vite's dev server for hot reloading
      log('Setting up Vite development server');
      await setupVite(app, server);

      await new Promise<void>((resolve, reject) => {
        server.listen(port, "0.0.0.0", (err?: Error) => {
          if (err) {
            reject(err);
            return;
          }
          log(`Server started successfully on port ${port}`);
          console.timeEnd('Total startup');
          resolve();
        });
      });

      return; // Successfully started
    } catch (err: any) {
      if (err.code === 'EADDRINUSE' && port < startPort + retries - 1) {
        log(`Port ${port} in use, trying next port...`);
        continue;
      }
      throw err;
    }
  }
  throw new Error(`Could not find an available port after ${retries} attempts`);
};

startServer().catch((err) => {
  console.error('Fatal error during server startup:', err);
  process.exit(1);
});