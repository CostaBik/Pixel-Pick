import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGameStateSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/game-state/:userId", async (req, res) => {
    const { userId } = req.params;
    const state = await storage.getGameState(userId);
    if (!state) {
      const defaultState = {
        userId,
        currency: 0,
        inventory: JSON.stringify({}),
        currentPickaxe: "wooden",
        miningPower: "0.5", // Changed to string to match schema
      };
      const newState = await storage.saveGameState(defaultState);
      res.json(newState);
    } else {
      res.json(state);
    }
  });

  app.post("/api/game-state/:userId", async (req, res) => {
    const { userId } = req.params;
    const updates = insertGameStateSchema.partial().parse(req.body);
    const updated = await storage.updateGameState(userId, updates);
    res.json(updated);
  });

  const httpServer = createServer(app);
  return httpServer;
}