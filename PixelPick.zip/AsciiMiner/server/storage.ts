import { gameStates, type GameState, type InsertGameState } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getGameState(userId: string): Promise<GameState | undefined>;
  saveGameState(state: InsertGameState): Promise<GameState>;
  updateGameState(userId: string, state: Partial<InsertGameState>): Promise<GameState>;
}

export class DatabaseStorage implements IStorage {
  async getGameState(userId: string): Promise<GameState | undefined> {
    const [state] = await db.select().from(gameStates).where(eq(gameStates.userId, userId));
    return state;
  }

  async saveGameState(state: InsertGameState): Promise<GameState> {
    const [savedState] = await db.insert(gameStates).values(state).returning();
    return savedState;
  }

  async updateGameState(
    userId: string,
    updates: Partial<InsertGameState>
  ): Promise<GameState> {
    const [updated] = await db
      .update(gameStates)
      .set(updates)
      .where(eq(gameStates.userId, userId))
      .returning();

    if (!updated) {
      throw new Error("Game state not found");
    }

    return updated;
  }
}

export const storage = new DatabaseStorage();