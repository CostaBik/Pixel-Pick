import { pgTable, text, serial, integer, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const gameStates = pgTable("game_states", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  currency: integer("currency").notNull().default(0),
  inventory: text("inventory").notNull(),
  currentPickaxe: text("current_pickaxe").notNull(),
  miningPower: decimal("mining_power").notNull().default('1'),
  recipes: text("discovered_recipes").notNull().default('[]'),
});

export const insertGameStateSchema = createInsertSchema(gameStates).pick({
  userId: true,
  currency: true,
  inventory: true,
  currentPickaxe: true,
  miningPower: true,
  recipes: true,
});

export type InsertGameState = z.infer<typeof insertGameStateSchema>;
export type GameState = typeof gameStates.$inferSelect;