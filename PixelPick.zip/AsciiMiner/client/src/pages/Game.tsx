import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MiningArea } from '@/components/game/MiningArea';
import { Inventory } from '@/components/game/Inventory';
import { Shop } from '@/components/game/Shop';
import { Crafting } from '@/components/game/Crafting';
import { useGameState } from '@/lib/gameState';
import type { GameState } from '@shared/schema';
import { Card } from '@/components/ui/card';

export default function Game() {
  const { userId, updateState } = useGameState();
  const [isInCave, setIsInCave] = useState(false);

  const { data: gameState, error, isLoading } = useQuery<GameState>({
    queryKey: [`/api/game-state/${userId}`],
    retry: 3,
  });

  useEffect(() => {
    if (gameState) {
      updateState({
        currency: gameState.currency,
        inventory: JSON.parse(gameState.inventory),
        currentPickaxe: gameState.currentPickaxe,
        miningPower: parseFloat(gameState.miningPower), // Convert string to number
      });
    }
  }, [gameState]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white p-4 flex items-center justify-center">
        <Card className="p-4">Loading game state...</Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 text-white p-4 flex items-center justify-center">
        <Card className="p-4 text-red-500">Error loading game state. Please refresh the page.</Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <div className="max-w-4xl mx-auto grid gap-4 grid-cols-1 md:grid-cols-2">
        <div className="col-span-full">
          <MiningArea isInCave={isInCave} setIsInCave={setIsInCave} />
        </div>
        <div>
          <Inventory />
        </div>
        {!isInCave && (
          <div className="space-y-4">
            <Shop />
            <Crafting />
          </div>
        )}
      </div>
    </div>
  );
}