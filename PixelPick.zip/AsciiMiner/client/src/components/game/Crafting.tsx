import { useGameState } from '@/lib/gameState';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CRAFTABLE_PICKAXES, RESOURCES } from '@/lib/gameTypes';
import { craftPickaxe } from '@/lib/gameState';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function Crafting() {
  const { inventory, currentPickaxe } = useGameState();

  const canCraft = (recipe: Record<string, number>) => {
    return Object.entries(recipe).every(
      ([item, amount]) => (inventory[item] ?? 0) >= amount
    );
  };

  const getResourceDisplayName = (resourceName: string) => {
    const resource = RESOURCES.find(r => r.name === resourceName);
    return resource ? resource.displayName : resourceName;
  };

  return (
    <Card className="p-4 bg-gray-800">
      <h2 className="text-xl font-bold mb-4 text-purple-500">Crafting</h2>
      <div className="space-y-2">
        {CRAFTABLE_PICKAXES.map((pickaxe) => {
          const hasRequirements = canCraft(pickaxe.recipe ?? {});

          return (
            <div
              key={pickaxe.name}
              className="flex flex-col p-2 bg-gray-700 rounded"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`${pickaxe.color} font-mono`}>
                    {pickaxe.symbol}
                  </span>
                  <span className="text-gray-200">
                    {pickaxe.displayName} (Power: {pickaxe.power})
                  </span>
                </div>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      disabled={!hasRequirements || currentPickaxe === pickaxe.name}
                      size="sm"
                      variant="outline"
                      className="text-purple-400 hover:text-purple-300"
                    >
                      Craft
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Confirm Crafting</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to craft this pickaxe?
                        (This will convert your mining power to the selected pickaxe.)
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => craftPickaxe(pickaxe.name)}>
                        Craft
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
              <div className="mt-2 text-sm text-gray-400">
                Requirements:
                {Object.entries(pickaxe.recipe ?? {}).map(([item, amount]) => (
                  <span
                    key={item}
                    className={`ml-2 ${
                      (inventory[item] ?? 0) >= amount
                        ? "text-green-400"
                        : "text-red-400"
                    }`}
                  >
                    {getResourceDisplayName(item)}: {inventory[item] ?? 0}/{amount}
                  </span>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}