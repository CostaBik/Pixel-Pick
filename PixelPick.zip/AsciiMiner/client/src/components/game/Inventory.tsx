import { useGameState, sellResource } from '@/lib/gameState';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { RESOURCES } from '@/lib/gameTypes';

export function Inventory() {
  const { inventory, currency } = useGameState();

  return (
    <Card className="p-4 bg-gray-800">
      <h2 className="text-xl font-bold mb-4 text-yellow-500">Inventory</h2>
      <div className="mb-4">
        <span className="text-yellow-400">Currency: {currency} 💰</span>
      </div>
      <div className="space-y-2">
        {Object.entries(inventory).map(([resource, amount]) => {
          const resourceData = RESOURCES.find((r) => r.name === resource);
          if (!resourceData) return null;

          return (
            <div
              key={resource}
              className="flex items-center justify-between p-2 bg-gray-700 rounded"
            >
              <span className={`${resourceData.color} font-mono`}>
                {resourceData.symbol} {resourceData.displayName}: {String(amount)}
              </span>
              <Button
                onClick={() => sellResource(resource)}
                size="sm"
                variant="outline"
                className="text-green-400 hover:text-green-300"
              >
                Sell
              </Button>
            </div>
          );
        })}
      </div>
    </Card>
  );
}