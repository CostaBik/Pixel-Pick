import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { CAVE_ENTRANCE, CAVE_INTERIOR, MINING_ANIMATION } from '@/lib/ascii';
import { mine } from '@/lib/gameState';

interface MiningAreaProps {
  isInCave: boolean;
  setIsInCave: (value: boolean) => void;
}

export function MiningArea({ isInCave, setIsInCave }: MiningAreaProps) {
  const [animationFrame, setAnimationFrame] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const handleMine = () => {
    setIsAnimating(true);
    mine();
    setTimeout(() => setIsAnimating(false), 500);
  };

  useEffect(() => {
    if (isAnimating) {
      const interval = setInterval(() => {
        setAnimationFrame((prev) => (prev + 1) % MINING_ANIMATION.length);
      }, 150);
      return () => clearInterval(interval);
    } else {
      setAnimationFrame(0); // Reset to default stance when not animating
    }
  }, [isAnimating]);

  const CaveEntrance = () => (
    <>
      <div className="bg-gray-800 rounded p-4 mb-4 overflow-x-auto">
        <pre className="font-mono text-xs sm:text-sm md:text-base text-center text-white whitespace-pre">
          {CAVE_ENTRANCE}
        </pre>
      </div>
      <div className="flex justify-center">
        <Button
          onClick={() => setIsInCave(true)}
          className="bg-yellow-600 hover:bg-yellow-700"
        >
          Enter Cave
        </Button>
      </div>
    </>
  );

  const CaveInterior = () => {
    const animation = MINING_ANIMATION[animationFrame].split('\n');
    const caveScene = CAVE_INTERIOR
      .replace('%PLAYER%', animation[0])
      .replace('%PLAYER2%', animation[1])
      .replace('%PLAYER3%', animation[2]);

    return (
      <>
        <div className="bg-gray-800 rounded p-4 mb-4 overflow-x-auto">
          <pre className="font-mono text-xs sm:text-sm md:text-base text-center text-white whitespace-pre">
            {caveScene}
          </pre>
        </div>
        <div className="flex justify-center gap-4">
          <Button
            onClick={handleMine}
            disabled={isAnimating}
            className="bg-yellow-600 hover:bg-yellow-700"
          >
            Mine!
          </Button>
          <Button
            onClick={() => setIsInCave(false)}
            variant="outline"
            className="text-gray-300"
          >
            Exit Cave
          </Button>
        </div>
      </>
    );
  };

  return (
    <Card className="p-4 bg-gray-900">
      {isInCave ? <CaveInterior /> : <CaveEntrance />}
    </Card>
  );
}