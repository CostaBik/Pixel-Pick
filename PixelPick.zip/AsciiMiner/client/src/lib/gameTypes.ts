export interface Resource {
  name: string;
  displayName: string;
  value: number;
  symbol: string;
  color: string;
  requiredPower: number;
}

export interface Pickaxe {
  name: string;
  displayName: string;
  power: number;
  cost: number | null; // null means it must be crafted
  symbol: string;
  color: string;
  recipe?: Record<string, number>; // required materials and their amounts
}

export interface Inventory {
  [key: string]: number;
}

export const RESOURCES: Resource[] = [
  { name: "coal", displayName: "Coal", value: 1, symbol: "■", color: "text-gray-600", requiredPower: 0.5 },
  { name: "copper_ore", displayName: "Copper Ore", value: 2, symbol: "◆", color: "text-orange-400", requiredPower: 1.0 },
  { name: "iron_ore", displayName: "Iron Ore", value: 3, symbol: "●", color: "text-gray-400", requiredPower: 1.5 },
  { name: "titanium_ore", displayName: "Titanium Ore", value: 5, symbol: "♦", color: "text-cyan-400", requiredPower: 2.0 },
  { name: "platinum_ore", displayName: "Platinum Ore", value: 8, symbol: "★", color: "text-blue-200", requiredPower: 2.5 },
  { name: "tungsten_ore", displayName: "Tungsten Ore", value: 12, symbol: "✧", color: "text-purple-400", requiredPower: 3.0 },
  { name: "diamond", displayName: "Diamond", value: 15, symbol: "💎", color: "text-blue-400", requiredPower: 3.5 },
];

export const PICKAXES: Pickaxe[] = [
  { name: "wooden", displayName: "Wooden Pickaxe", power: 0.5, cost: 0, symbol: "⚒", color: "text-yellow-800" },
  { name: "stone", displayName: "Stone Pickaxe", power: 1.0, cost: 50, symbol: "⛏", color: "text-gray-500" },
  { name: "copper", displayName: "Copper Pickaxe", power: 1.5, cost: null, symbol: "🔨", color: "text-orange-400", 
    recipe: { copper_ore: 5 } },
  { name: "iron", displayName: "Iron Pickaxe", power: 2.0, cost: 200, symbol: "⚒", color: "text-gray-300" },
  { name: "titanium", displayName: "Titanium Pickaxe", power: 2.5, cost: null, symbol: "⛏", color: "text-cyan-400",
    recipe: { titanium_ore: 5, iron_ore: 3 } },
  { name: "platinum", displayName: "Platinum Pickaxe", power: 3.0, cost: null, symbol: "🔨", color: "text-blue-200",
    recipe: { platinum_ore: 5, titanium_ore: 2 } },
  { name: "tungsten", displayName: "Tungsten Pickaxe", power: 3.5, cost: null, symbol: "⚒", color: "text-purple-400",
    recipe: { tungsten_ore: 5, platinum_ore: 2 } },
  { name: "diamond", displayName: "Diamond Pickaxe", power: 4.0, cost: 1000, symbol: "💎", color: "text-blue-400" },
];

export const SHOP_PICKAXES = PICKAXES.filter(p => p.cost !== null);
export const CRAFTABLE_PICKAXES = PICKAXES.filter(p => p.recipe !== undefined);