export const CAVE_ENTRANCE = `
    ╔══════════════════════════════════════╗
    ║           MINE ENTRANCE              ║
    ║              ⛰️  ⛰️                   ║
    ║       ▄▄███████████████▄▄            ║
    ║      ██████████████████████          ║
    ║     ████████ ENTER ████████          ║
    ║    ██████████████████████████        ║
    ╚══════════════════════════════════════╝
`;

export const CAVE_INTERIOR = `
  ▄▄███████▄▄
▄████████████▄
██████████████████
████████████████████             %PLAYER%
██████████████████████           %PLAYER2%
████████████████████████          %PLAYER3%
`;

export const MINING_ANIMATION = [
`⛏   O     
    /|\\   
    / \\   `,

`   O     
⛏  /|\\   
    / \\   `,

`    O    
    /|\\   
⛏  / \\   `,

`   O    
⛏  /|\\   
    / \\   `
];

export function generateMiningArea(resources: string[][]): string {
  let output = "";
  for (let row of resources) {
    output += row.join(" ") + "\n";
  }
  return output;
}