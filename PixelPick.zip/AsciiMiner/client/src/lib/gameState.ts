import { create } from 'zustand';
import { RESOURCES, PICKAXES, type Inventory } from './gameTypes';
import { apiRequest } from './queryClient';

interface GameState {
  userId: string;
  currency: number;
  inventory: Inventory;
  currentPickaxe: string;
  miningPower: number;
  updateState: (updates: Partial<Omit<GameState, 'updateState'>>) => void;
}

export const useGameState = create<GameState>((set) => ({
  userId: "player1",
  currency: 0,
  inventory: {},
  currentPickaxe: "wooden",
  miningPower: 0.5,
  updateState: (updates) => set((state) => ({ ...state, ...updates })),
}));

// Helper function to save game state to the server
async function saveGameState() {
  const state = useGameState.getState();
  try {
    await apiRequest('POST', `/api/game-state/${state.userId}`, {
      currency: state.currency,
      inventory: JSON.stringify(state.inventory),
      currentPickaxe: state.currentPickaxe,
      miningPower: state.miningPower.toString(), // Convert number to string
    });
  } catch (error) {
    console.error('Failed to save game state:', error);
  }
}

// Mining function to collect resources
export const mine = async () => {
  const state = useGameState.getState();
  const availableResources = RESOURCES.filter(r => r.requiredPower <= state.miningPower);
  if (availableResources.length === 0) return;

  const resource = availableResources[Math.floor(Math.random() * availableResources.length)];

  const inventory = { ...state.inventory };
  inventory[resource.name] = (inventory[resource.name] || 0) + 1;

  useGameState.setState({ inventory });
  await saveGameState();
};

// Function to sell resources
export const sellResource = async (resourceName: string) => {
  const state = useGameState.getState();
  const resource = RESOURCES.find(r => r.name === resourceName);
  if (!resource || !state.inventory[resourceName]) return;

  const amount = state.inventory[resourceName];
  const value = resource.value * amount;

  const inventory = { ...state.inventory };
  delete inventory[resourceName];

  useGameState.setState({
    inventory,
    currency: state.currency + value
  });
  await saveGameState();
};

// Function to buy pickaxes from shop
export const buyPickaxe = async (pickaxeName: string) => {
  const state = useGameState.getState();
  const pickaxe = PICKAXES.find(p => p.name === pickaxeName);
  if (!pickaxe || pickaxe.cost === null || state.currency < pickaxe.cost) return;

  useGameState.setState({
    currency: state.currency - pickaxe.cost,
    currentPickaxe: pickaxe.name,
    miningPower: pickaxe.power
  });
  await saveGameState();
};

// Function to craft pickaxes using resources
export const craftPickaxe = async (pickaxeName: string) => {
  const state = useGameState.getState();
  const pickaxe = PICKAXES.find(p => p.name === pickaxeName);
  if (!pickaxe || !pickaxe.recipe) return;

  // Check if we have all required materials
  const canCraft = Object.entries(pickaxe.recipe).every(
    ([item, amount]) => (state.inventory[item] ?? 0) >= amount
  );

  if (!canCraft) return;

  // Remove materials used in crafting
  const inventory = { ...state.inventory };
  Object.entries(pickaxe.recipe).forEach(([item, amount]) => {
    inventory[item] -= amount;
    if (inventory[item] <= 0) {
      delete inventory[item];
    }
  });

  useGameState.setState({
    inventory,
    currentPickaxe: pickaxe.name,
    miningPower: pickaxe.power
  });
  await saveGameState();
};